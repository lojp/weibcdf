# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVR
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import timeit
import heapq
start = timeit.default_timer()


year = 2019
names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','LOGIC']
df_raw = pd.read_csv('C:/jluo/Export/CPUDAT.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')  #,skiprows=3
df_raw.columns = names

df_raw['VL'] =df_raw['Vehicle Line Global'].str.split(' - ').str[0]

# dfv = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='utf-8')
# partlist= pd.pivot_table(dfv,index=['Vehicle Line Global'], values=['WCC'],aggfunc='count').reset_index()
# partlist.columns = ['Vehicle Line Global','Count']
# partlist['VL'] = partlist['Vehicle Line Global'].str.split(' - ').str[0]


# df = pd.merge(df_raw, partlist[['VL', 'Vehicle Line Global']],how='left', on=['VL'])

# df = df[df['Vehicle Line Global'] != 'TOTAL']
# df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]

df = df_raw[df_raw['Vehicle Line Global'] != 'TOTAL']
df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)


ind = df['INDEXS'].unique()
ind_df = pd.DataFrame({'INDEXS':ind})

ydf = df[df['MODEL YEAR'] == year]
ddf = pd.pivot_table(ydf,index=['INDEXS'], values=['TIS'],aggfunc='max').reset_index()
ddf.columns = ['INDEXS','TIS_MAX']
ddf = pd.merge(ind_df,ddf,how='left', on=['INDEXS'])
# ddf['TIS_MAX'] = np.where(np.isnan(ddf['TIS_MAX']), 6, ddf['TIS_MAX'])
ddf['TIS_MAX'] = np.where(np.isnan(ddf['TIS_MAX']), 3,3)

newdf = pd.merge(ddf, df.drop(['MATRIX','PROD_MONTH','R1000','CPR','LOGIC'],axis=1) ,how='left', on=['INDEXS'])
# ndf = newdf[newdf['TIS'] == newdf['TIS_MAX']]
ndf = newdf[(newdf['TIS'] == newdf['TIS_MAX'])  &(newdf['MODEL YEAR'] >= year-5)]
cols = ['INDEXS','TIS_MAX','TIS','REPAIRS','VEHICLES','COSTS','CPU','MODEL YEAR','VL','PART NUM BASE (CAUSL)','Vehicle Line Global']
ndf.to_csv('C:/jluo/Export/CPUVLPart.csv',columns=cols, index=None)
# # print(ttl_df.head(9))

# yy = [2014,2015,2016,2017,2018]
# for yr in yy:
    # ttl_df= ndf[ndf['MODEL YEAR'] >=yr]
    # # ttl_df= ttl_df[ttl_df['MODEL YEAR'] >2016]
    # x= ttl_df['COSTS'].values.tolist()
    # y= ttl_df['CPU'].values.tolist()
    # area = (ttl_df['VEHICLES']/500).values.tolist()
    # color = ttl_df['MODEL YEAR'].values.tolist()
    # n = ttl_df['INDEXS'].values.tolist()

    # # fig = plt.figure(figsize=(15,5))
    # # plt.scatter(x, y, s= area, marker='o',c=color, alpha=0.5)
    # # plt.show()


    # bounds = [2013.1,2014.1,2015.1,2016.1,2017.1,2018.1]
    # colors = ["darkorchid","g", "y", "b", "r"]
    # cmap = matplotlib.colors.ListedColormap(colors)
    # norm = matplotlib.colors.BoundaryNorm(bounds, len(colors))


    # fig, ax = plt.subplots(figsize=(15,7))
    # sc = ax.scatter(x, y,s= area, marker='o',c=color, cmap=cmap, norm=norm)
    # ax.set_xlim([0,420000])
    # ax.set_ylim([0,20])
    # cbar = fig.colorbar(sc, spacing="proportional",fraction=0.046, pad=0.04)
    # cbar.ax.get_yaxis().set_ticks([])
    # for j, lab in enumerate(['$2014$','$2015$','$2016$','$2017$','$2018$']):
        # cbar.ax.text(.5, (2 * j + 1) / 10, lab, ha='center', va='center',fontsize=7)
    # for i, txt in enumerate(n):
        # ax.annotate(txt, (x[i],y[i]),fontsize=7)
    # fig.set_tight_layout(True)
    # ax.set_xlabel('Costs')
    # ax.set_ylabel('CPU')
    # ax.set_title(r'AP EESE CPU SCATTER PLOT(@MIS=4)')
    # # ax.legend(loc=0)
    # fig.savefig('C:/jluo/jluo27/CPU/CPU_From' + str(yr) + '.png')
    # # fig.savefig('C:/Users/jluo27/Desktop/CPU_all2.png')
    # # plt.show()