# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVR
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors
import seaborn as sns
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import timeit
import heapq
from PyPDF2 import PdfFileReader, PdfFileMerger
import os
start = timeit.default_timer()

year = 2018
type_list=['R1000','CPU']
files_dir = "C:/jluo/jluo27/CPU"
os.chdir(files_dir)
merger = PdfFileMerger()

names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','VL','PART NUM BASE (CAUSL)','QBs','LOGIC']
df_raw = pd.read_csv('C:/jluo/Export/PYDAT.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')  #,skiprows=3
df_raw.columns = names

dfv = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='utf-8')
partlist= pd.pivot_table(dfv,index=['Vehicle Line Global'], values=['WCC'],aggfunc='count').reset_index()
partlist.columns = ['Vehicle Line Global','Count']
partlist['VL'] = partlist['Vehicle Line Global'].str.split(' - ').str[0]

all_df = pd.merge(df_raw, partlist[['VL', 'Vehicle Line Global']],how='left', on=['VL'])
all_df = all_df[all_df['VL'] != 'TOTAL']
all_df = all_df[(all_df['VL']=='U2')  |  (all_df['VL']=='B4')]
# all_df = all_df[(all_df['VL']=='B4')]
qb = all_df['QBs'].sort_values().unique()

csv_df = all_df[(all_df['TIS'] == 6) & (all_df['VEHICLES'] >=40)]
csv_df.to_csv('RAWDATA_VLPART.csv', index=None)


for i in range(len(qb)):
# for i in range(2):
    try:
        df = all_df[all_df['QBs']==qb[i]]
        df['IDX'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)

        ind = df['IDX'].unique()
        ind_df = pd.DataFrame({'IDX':ind})

        ydf = df[df['MODEL YEAR'] == year]
        ddf = pd.pivot_table(ydf,index=['IDX'], values=['TIS'],aggfunc='max').reset_index()
        ddf.columns = ['IDX','TIS_MAX']
        ddf = pd.merge(ind_df,ddf,how='left', on=['IDX'])
        # ddf['TIS_MAX'] = np.where(np.isnan(ddf['TIS_MAX']), 6, ddf['TIS_MAX'])
        ddf['TIS_MAX'] = np.where(np.isnan(ddf['TIS_MAX']), 6, 6)

        newdf = pd.merge(ddf, df.drop(['MATRIX','PROD_MONTH','CPR','LOGIC'],axis=1) ,how='left', on=['IDX'])
        ndf = newdf[(newdf['TIS'] == newdf['TIS_MAX']) & (newdf['VEHICLES'] >=100)]
        # ndf.to_csv('RAWDATA_VLPART_' + qb[i] + '.csv', index=None)
        for j in range(len(type_list)):
            rank_df = pd.pivot_table(ndf,index=['IDX'],columns=['MODEL YEAR'], values=type_list[j],aggfunc='max').reset_index()
            rank_df.columns = ['IDX','2013','2014','2015','2016','2017','2018']
            rank_df = rank_df.sort_values(by=['2018', '2017','2016','2015','2014','2013','IDX'], ascending=False)
            rank_df = rank_df.head(20)
            final_df = pd.merge(rank_df.drop(['2013','2014','2015','2016','2017','2018'],axis=1),ndf, how='left', on=['IDX'])
    
            value_max =min(math.ceil(max(rank_df['2018'])/100)*100,200)
            
            g = sns.FacetGrid(final_df, col="IDX", col_wrap=5)
            g.fig.suptitle('AP TOP 20 VEHICLES + PARRTS ' +' FOR ' + type_list[j] + '(@MIS=6) \n' + qb[i]) # can also get the figure from plt.gcf() BODY INYERIOR
            g.fig.text(0.02, 0.05, "Vehicle volume in 6 MIS: >=100", ha ='left',color='b')
            g = (g.map(plt.plot, "MODEL YEAR", type_list[j], marker="o",color="r")
                   .set(xlim=(2013-0.5, 2018+0.5), ylim=(0, value_max),
                    xticks=[2013,2014,2015,2016,2017,2018], yticks=[value_max/4, value_max/2, value_max*3/4])
                    .set_titles("{col_name}")
                    .fig.subplots_adjust(top=.9,bottom=0.11,left=0.05,right=0.96,wspace=.13, hspace=.34)
                    )
            filename = 'Top20_VLPART_' + type_list[j] + '_' + qb[i] + '.pdf'
            plt.savefig(filename)
            merger.append(PdfFileReader(os.path.join(files_dir, filename), 'rb'))
            # os.remove(os.path.join(files_dir, filename))
        print(i+1,'--->', qb[i])
    except:
        # print('4')
        continue

merger.write("Top20_VLPART.pdf")