# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""

from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn import preprocessing
from sklearn.svm import SVR
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
# from distcdf import *
import timeit
start = timeit.default_timer()

year = 2016
names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','LOGIC','K']
df = pd.read_csv('C:/jluo/Export/CPUDAT.CSV',encoding='utf-8')
# df.columns = names
df = df[df['MODEL YEAR'] == year]
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
ddf = pd.pivot_table(df,index=['INDEXS'], values=['TIS'],aggfunc='max').reset_index()
ddf.columns = ['INDEXS','TIS_MAX']
newdf = pd.merge(ddf, df.drop(['PROD_MONTH','CPU','CPR','LOGIC'],axis=1) ,how='left', on=['INDEXS'])



def r(x,y):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot)

    
def trend_code(x):
    if type(x) is str:
        return x
    elif x>0.9999:
        return 2
    elif x==0:
        return 0
    else:
        return 1

def weibull_cdf(x, a, b):
    return 1 - np.exp(-(x / b) ** a)

def exponetial_cdf(x, lambd, a=0):
    """CDF of exponetial distribution."""
    return 1 - np.exp(-lambd*x) + a
	
def normal_cdf(x, mu, sigma):
    return 0.5*sp.erfc((mu-x)/(sigma*np.sqrt(2.0)))

def lognormal_cdf(x,mean,sigma):
    z    = (np.log(x)-mean)/float(sigma)
    y  = 0.5*(sp.erfc(-z/np.sqrt(2)))
    return y

dists = ['Exponetial','Lognormal','Normal','Weibull']
tis_list =[12,24,36]

report = pd.DataFrame() 
for i in range(len(ddf)):
# for i in range(600):
    try:
        ndf = newdf[(newdf['MODEL YEAR'] == year) & (newdf['INDEXS'] == ddf.loc[i, 'INDEXS'])]
        N = ddf.loc[i, 'TIS_MAX']
        ydata = list(ndf['R1000'][1:N+1]/1000)
        x = ar(range(1,N+1))
        y = ar(ydata)
        xx = ar(range(1,37))
        rpr = ar(list(ndf['REPAIRS'][1:N+1]))
        ndf1 = ndf.head(4).reset_index(drop=True)

        tt = pd.DataFrame()
        if max(y) > 0.03: 
            poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
            popte,pcove =  curve_fit(exponetial_cdf,x,y, bounds=(0, [5, 100]))
            poptn,pcovn =  curve_fit(normal_cdf,x,y)
            poptl,pcovl =  curve_fit(lognormal_cdf,x,y)

            resiw = y- weibull_cdf(x, *poptw)
            resie = y- exponetial_cdf(x, *popte)
            resin = y- normal_cdf(x, *poptn)
            resil = y- lognormal_cdf(x, *poptl)

            ttw = weibull_cdf(36, *poptw)
            tte = exponetial_cdf(36, *popte)
            ttn = normal_cdf(36, *poptn)
            ttl = lognormal_cdf(36, *poptl)
	
            df_tt = pd.DataFrame({'Weibull': r(resiw,y), 'Exponetial': r(resie,y),'Normal': r(resin,y), 'Lognormal': r(resil,y)}, index=[0])
            df_tt = df_tt.append(pd.DataFrame({'Weibull': ttw, 'Exponetial': tte,'Normal': ttn, 'Lognormal': ttl}, index=[0]), ignore_index=True)


#--------------------------------------------------------------------------------------------------------------------------	   
            for j in range(len(tis_list)):
                tt_w = weibull_cdf(tis_list[j], *poptw) - weibull_cdf(tis_list[j]-11, *poptw)
                tt_e = exponetial_cdf(tis_list[j], *popte) - exponetial_cdf(tis_list[j]-11, *popte)
                tt_n = normal_cdf(tis_list[j], *poptn) - normal_cdf(tis_list[j]-11, *poptn)
                tt_l = lognormal_cdf(tis_list[j], *poptl) - lognormal_cdf(tis_list[j]-11, *poptl)
                tt = tt.append(pd.DataFrame({'Weibull': tt_w, 'Exponetial': tt_e,'Normal': tt_n, 'Lognormal': tt_l}, index=[0]), ignore_index=True)
            # print(tt)
            cc = tt.values #returns a numpy array
            min_max_scaler = preprocessing.MinMaxScaler()
            x_scaled = min_max_scaler.fit_transform(cc)
            kk = pd.DataFrame(x_scaled, columns=tt.columns).applymap(trend_code)
            kk = kk.transpose()
            kk['trend'] = kk[[0,1,2]].apply(lambda x : '{}-{}-{}'.format(x[0],x[1],x[2]), axis=1)
            kk = kk.drop([0,1,2],axis=1)
            # print(kk)           
            df_tt = df_tt.append(tt)  
            df_ntt = df_tt.transpose()
            df_ntt.sort_index(inplace=True)
            df_ntt.columns =['r2','fc_36','slope12','slope24','slope36']    #convert column to row
            new_df = pd.merge(df_ntt, kk, left_index=True, right_index=True)
            new_df['distribution'] = new_df.index
            new_df.index= range(len(new_df.index))
            rpt = pd.concat([new_df, ndf1[['INDEXS','MODEL YEAR']]], axis=1)
            report = report.append(rpt)
            print(round(i*100/len(ddf),1),'%, ',len(ddf),i)
        else:
            continue
            # print("min")      
    except:
        # print(tuple(yy))
        # plt.figure(figsize=(14,8))
        # plt.step(x,y,'b-',where='mid')
        # plt.plot(xx, yy, 'r--')
        # plt.ylim([0, 0.01])
        # plt.xlim([0, 36])
        # plt.show()
        continue
    # print(round(i*100/len(ddf),1),'%, ',len(ddf),i)

report.to_csv('C:/jluo/Export/rpt_tis' + str(year) +'.CSV', encoding='utf-8',index=False)
stop = timeit.default_timer()
print (round(stop - start,3),'s')





















    
    


	
