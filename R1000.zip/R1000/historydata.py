# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn import preprocessing
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *

year = 2017
df = pd.read_csv('C:/jluo/Export/TISREPtest.CSV', encoding='utf-8')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
ndf = df[(df['MODEL YEAR'] == year) & (df['PART NUM BASE (CAUSL)'] == 'TOTAL') & (df['PROD_MONTH'].isnull())]
ndf1 = ndf.head(4).reset_index(drop=True)


N = 12
ydata = list(ndf['R1000'][1:N+1]/1000)
x = ar(range(1,N+1))
y = ar(ydata)
xx = ar(range(1,37))
dists = ['Exponetial','Lognormal','Normal','Weibull']
tis_list =[12,24,36]

def weibull_cdf(x, a, b):
    return 1 - np.exp(-(x / b) ** a)

def exponetial_cdf(x, lambd, a=0):
    """CDF of exponetial distribution."""
    return 1 - np.exp(-lambd*x) + a
	
def normal_cdf(x, mu, sigma):
    return 0.5*sp.erfc((mu-x)/(sigma*np.sqrt(2.0)))

def lognormal_cdf(x,mean,sigma):
    z    = (np.log(x)-mean)/float(sigma)
    y  = 0.5*(sp.erfc(-z/np.sqrt(2)))
    return y

def r(x,y):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot)

    
    

def trend_code(x):
    if type(x) is str:
        return x
    elif x>0.9999:
        return 2
    elif x==0:
        return 0
    else:
        return 1
tt = pd.DataFrame()
	
if max(y) > 0.08: 	
    poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
    popte,pcove =  curve_fit(exponetial_cdf,x,y)
    poptn,pcovn =  curve_fit(normal_cdf,x,y)
    poptl,pcovl =  curve_fit(lognormal_cdf,x,y)

    resiw = y- weibull_cdf(x, *poptw)
    resie = y- exponetial_cdf(x, *popte)
    resin = y- normal_cdf(x, *poptn)
    resil = y- lognormal_cdf(x, *poptl)

    ttw = weibull_cdf(36, *poptw)
    tte = exponetial_cdf(36, *popte)
    ttn = normal_cdf(36, *poptn)
    ttl = lognormal_cdf(36, *poptl)
	
    df_tt = pd.DataFrame({'Weibull': r(resiw,y), 'Exponetial': r(resie,y),'Normal': r(resin,y), 'Lognormal': r(resil,y)}, index=[0])
    df_tt = df_tt.append(pd.DataFrame({'Weibull': ttw, 'Exponetial': tte,'Normal': ttn, 'Lognormal': ttl}, index=[0]), ignore_index=True)


#--------------------------------------------------------------------------------------------------------------------------	   
    for j in range(len(tis_list)):
        tt_w = weibull_cdf(tis_list[j], *poptw) - weibull_cdf(tis_list[j]-11, *poptw)
        tt_e = exponetial_cdf(tis_list[j], *popte) - exponetial_cdf(tis_list[j]-11, *popte)
        tt_n = normal_cdf(tis_list[j], *poptn) - normal_cdf(tis_list[j]-11, *poptn)
        tt_l = lognormal_cdf(tis_list[j], *poptl) - lognormal_cdf(tis_list[j]-11, *poptl)
        tt = tt.append(pd.DataFrame({'Weibull': tt_w, 'Exponetial': tt_e,'Normal': tt_n, 'Lognormal': tt_l}, index=[0]), ignore_index=True)
    cc = tt.values #returns a numpy array
    min_max_scaler = preprocessing.MinMaxScaler()
    x_scaled = min_max_scaler.fit_transform(cc)
    kk = pd.DataFrame(x_scaled, columns=tt.columns).applymap(trend_code)
    kk = kk.transpose()
    kk['trend'] = kk[[0,1,2]].apply(lambda x : '{}-{}-{}'.format(x[0],x[1],x[2]), axis=1)
    kk = kk.drop([0,1,2],axis=1)

    df_tt = df_tt.append(tt)  
    df_ntt = df_tt.transpose()
    df_ntt.sort_index(inplace=True)
    df_ntt.columns =['r2','fc_36','slope12','slope24','slope36']    #convert column to row
    newdf = pd.merge(df_ntt, kk, left_index=True, right_index=True)
    newdf['distribution'] = newdf.index
    newdf.index= range(len(newdf.index))
    rpt = pd.concat([newdf, ndf1[['INDEXS','MODEL YEAR']]], axis=1)
    print(rpt)
    # print(ndf[ndf.index=='Lognormal'])
#--------------------------------------------------------------------------------------------------------------------------	


	
    # ntt = tt.apply(lambda x: x/x.max(), axis=0)   #按照最大值缩放
    # print(ntt)
#--------------------------------------------------------------------------------------------------------------------------	
    # ttw = weibull_cdf(36, *poptw)
    # tte = exponetial_cdf(36, *popte)
    # ttn = normal_cdf(36, *poptn)
    # ttl = lognormal_cdf(36, *poptl)

    # lt_r  = []
    # lt_r.append(r(resiw,y,ttw))
    # lt_r.append(r(resie,y,tte))
    # lt_r.append(r(resin,y,ttn))
    # lt_r.append(r(resil,y,ttl))
    # r_squared,ttvalue = zip(*lt_r)

    # index, value = max(enumerate(r_squared), key=operator.itemgetter(1))
    # ind, val = max(enumerate(ttvalue), key=operator.itemgetter(1))

    # plt.style.use('ggplot')
    # fig, axs = plt.subplots(2,2, figsize=(14, 8))
    # fig.subplots_adjust(hspace = .25, wspace=.1)
    # axs = axs.ravel()
    # plt.suptitle('The Best Distribution is ' + dists[index] + '\n' + 'F(36)=' + str(round(ttvalue[index],4)), fontsize=16)
    # axs[0].plot(xx,weibull_cdf(xx,*poptw),'r--',label='fit')
    # axs[1].plot(xx,exponetial_cdf(xx,*popte),'r--',label='fit')
    # axs[2].plot(xx,normal_cdf(xx,*poptn),'r--',label='fit')
    # axs[3].plot(xx,lognormal_cdf(xx,*poptl),'r--',label='fit')
    
    # for i in range(4):
        # axs[i].step(x,y,'b-',where='mid',label='data')
        # axs[i].set_title(dists[i])
        # axs[i].set_ylim([0, round(val*5)/5])
        # axs[i].text(30, val*0.05, r'$R^{2} = $' + str(round(r_squared[i],5)))
        # if i == index:
            # axs[i].text(30, val*0.6, r'$\checkmark$',fontsize=32,color='red')
#--------------------------------------------------------------------------------------------------------------------------
            # # axs[i].text(-1, val*0.95, round(ttvalue[i],4),color='red')
            # # axs[i].arrow(36, ttvalue[i], -37, 0, color='k',lw=0.3,ls='--')
    # plt.show()	
    # fig = plt.figure(figsize=(8,6))
    # plt.plot([0,1,2],ntt['weibull'],'b+--',label='w')
    # plt.plot([0,1,2],ntt['exponetial'],'g--+',label='e')
    # plt.plot([0,1,2],ntt['normal'],'r+--',label='n')
    # plt.plot([0,1,2],ntt['lognormal'],'k--+',label='l')
    # plt.legend()
    # plt.show()	
	

    # fcrpt = pd.DataFrame() 
    # if index ==0:
        # fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist()
    # elif index == 1:
    	# fcrpt['Forecast_R1000'] = (exponetial_cdf(xx,*popte)*1000).tolist()
    # elif index == 2:
    	# fcrpt['Forecast_R1000'] = (normal_cdf(xx,*poptn)*1000).tolist()
    # else:
    	# fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
    # fcrpt['TIS'] = xx.tolist()
    # fcrpt['MODEL YEAR'] = year
    # rpt = pd.merge(fcrpt, ndf[['MODEL YEAR','TIS','R1000','VEHICLES']],how='outer', on=['MODEL YEAR','TIS'])
    # rpt.sort_values(by=['TIS']).to_csv('C:/jluo/Export/rpt_tis.CSV', encoding='utf-8',index=False,columns=['MODEL YEAR','TIS','VEHICLES','R1000','Forecast_R1000'])

else:
    model = LinearRegression()
    model.fit(pd.DataFrame(x), pd.DataFrame(y))
    yy = model.predict(pd.DataFrame(xx))
    plt.figure(figsize=(14,8))
    plt.step(x,y,'b-',where='mid')
    plt.plot(xx, yy, 'r--')
    plt.ylim([0, 0.01])
    plt.xlim([0, 36])
    plt.show()