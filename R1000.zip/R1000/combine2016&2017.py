# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *

# year = 2017
# names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','LOGIC','K']
# df = pd.read_csv('C:/jluo/Export/CPUDAT.CSV', skiprows=5, header=None)
# df.columns = names
# df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
# df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
# ddf = pd.pivot_table(df,index=['INDEXS'], values=['TIS'],aggfunc='max').reset_index()
# ddf.columns = ['INDEXS','TIS_MAX']
# ndf = pd.merge(ddf, df.drop(['MATRIX','PROD_MONTH','CPU','CPR','LOGIC','K'],axis=1) ,how='left', on=['INDEXS'])
# print(ddf.loc[1, 'INDEXS'])



# bpdf = pd.read_csv('C:/jluo/Export/bpno_nov.csv')
# bpddf = pd.pivot_table(bpdf,index=['Base Part Number'], values=['Base Part Description'],aggfunc='max').reset_index()
# bpddf.columns = ['PART NUM BASE (CAUSL)','Base Part Description']
# # bpddf.sort_values(by=['Base Part Number']).to_csv('C:/jluo/Export/BPNO.CSV', encoding='utf-8',index=False)

# names = ['MATRIX','PROD_MONTH','REPAIRS','COSTS','VEHICLES','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','QB Global Hardware','LOGIC']
# df = pd.read_csv('C:/jluo/Export/QBdatabase.CSV', skiprows=5, header=None)
# df.columns = names
# df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
# df['QB'] = df['QB Global Hardware'].str.split(' - ').str[0]
# df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
# ddf = pd.pivot_table(df,index=['INDEXS','QB','Vehicle Line Global'], values=['REPAIRS'],aggfunc='sum').reset_index()
# ddf = ddf.sort_values(by=['REPAIRS','INDEXS','QB','Vehicle Line Global'], ascending=False)
# ndf = pd.pivot_table(ddf,index=['INDEXS','Vehicle Line Global'], values=['QB'],aggfunc='first').reset_index()
# ndf['PART NUM BASE (CAUSL)'] = ndf['INDEXS'].str.split('_').str[1]

# db = pd.merge(bpddf, ndf[['INDEXS','QB','Vehicle Line Global','PART NUM BASE (CAUSL)']],how='right', on=['PART NUM BASE (CAUSL)'])
# db.to_csv('C:/jluo/Export/QBdb.CSV', encoding='utf-8',index=False, columns = ['INDEXS','QB','Vehicle Line Global','PART NUM BASE (CAUSL)','Base Part Description'])
# # print(db.head(5))

#___________________________________________
# 生成2017报告
list = ['Exponetial_immature','Linear_immature','Lognormal_immature','Weibull_immature']
df = pd.read_csv('C:/jluo/Export/QBdb.CSV')
tisdf = pd.read_csv('C:/jluo/Export/rpt_tis2017.CSV')
# filterdf = pd.pivot_table(tisdf,index=['INDEXS'], values=['Forecast_R1000'],aggfunc='max').reset_index()
filterdf =tisdf[tisdf['TIS']==36]
filterdf =filterdf[filterdf['Model'].isin(list)==False]
filterdf = filterdf[filterdf['Forecast_R1000']>50]
ftisdf =  tisdf[tisdf['INDEXS'].isin(filterdf['INDEXS'])]
# print(ftisdf.head(5))
db = pd.merge(ftisdf, df[['INDEXS','QB','Vehicle Line Global','PART NUM BASE (CAUSL)','Base Part Description']],how='left', on=['INDEXS'])
# db.to_csv('C:/jluo/Export/tisrpt2017.CSV', encoding='utf-8',index=False)
ndf = pd.read_csv('C:/jluo/Export/rpt_tis2016.CSV')
ndb = pd.merge(db,ndf,how='left', on=['INDEXS','TIS'])
ttl_df = pd.pivot_table(ndb,index=['Vehicle Line Global','PART NUM BASE (CAUSL)'], values=['INDEXS'],aggfunc='count').reset_index()
ttl_df['vl'] = ttl_df['Vehicle Line Global'].str.split(' - ').str[0]
ttl_df['item'] = ttl_df[['vl','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
ttl_df['Type'] =2
ttl_df['PartSum'] = ttl_df['PART NUM BASE (CAUSL)']
ttl_df = ttl_df.drop(['PART NUM BASE (CAUSL)','Vehicle Line Global','INDEXS'],axis=1)
ttl_df.to_csv('C:/jluo/Export/Monthly/temp_Partlist.CSV', encoding='utf-8',index=False,columns=['Type','item','PartSum','vl'])
ndb.to_csv('C:/jluo/Export/tisrpt.CSV', encoding='utf-8',index=False)