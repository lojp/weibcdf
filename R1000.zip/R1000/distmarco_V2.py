# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVR
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import timeit
import heapq
start = timeit.default_timer()

def r(x,y,z):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot),z

dists = ['Weibull','Exponetial','Normal','Lognormal','Logistic']
tis_list =[12,24,36]
names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','LOGIC']
raw_df = pd.read_csv('C:/jluo/Export/CPUDATA.CSV', header=None)
raw_df.columns = names

# year = 2015

reportall= pd.DataFrame()
yrlist =[2013,2014,2015,2016,2017,2018]
for y in range(len(yrlist)):   
    try:
        year = yrlist[y]
        df = raw_df[raw_df['MODEL YEAR'] == year]
        df['VL'] = df['Vehicle Line Global'].str.split(' - ',expand=False).str[0]
        df['IDX'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
        ddf = pd.pivot_table(df,index=['IDX'], values=['TIS'],aggfunc='max').reset_index()
        ddf.columns = ['IDX','TIS_MAX']
        newdf = pd.merge(ddf, df.drop(['MATRIX','PROD_MONTH','CPU','CPR','LOGIC'],axis=1) ,how='left', on=['IDX'])


        report = pd.DataFrame() 
        for i in range(len(ddf)):
        # for i in range(500):
            try:
                ndf = newdf[(newdf['MODEL YEAR'] == year) & (newdf['IDX'] == ddf.loc[i, 'IDX'])]
                N = ddf.loc[i, 'TIS_MAX']   #提出不成熟的最后一个数字
                ydata1 = list(ndf['R1000'][1:N+1]/1000)
                if max(ydata1) > 3 * heapq.nlargest(2,ydata1)[1]:
                    N = N-1
                ydata = list(ndf['R1000'][1:N+1]/1000)
                x = ar(range(1,N+1))
                y = ar(ydata)
                xx = ar(range(1,37))
                rpr = ar(list(ndf['REPAIRS'][1:N+1]))
            

        # def weibull_cdf(x, a, b):
            # return 1 - np.exp(-(x / b) ** a)

        # def exponetial_cdf(x, lambd, a=0):
            # """CDF of exponetial distribution."""
            # return 1 - np.exp(-lambd*x) + a
            
        # def normal_cdf(x, mu, sigma):
            # return 0.5*sp.erfc((mu-x)/(sigma*np.sqrt(2.0)))

        # def lognormal_cdf(x,mean,sigma):
            # z    = (np.log(x)-mean)/float(sigma)
            # y  = 0.5*(sp.erfc(-z/np.sqrt(2)))
            # return y

            
                fcrpt = pd.DataFrame() 
                if max(rpr) > 5: 		
                    poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
                    popte,pcove =  curve_fit(exponetial_cdf,x,y)
                    poptn,pcovn =  curve_fit(normal_cdf,x,y)
                    poptl,pcovl =  curve_fit(lognormal_cdf,x,y)
                    # poptg,pcovg =  curve_fit(logistic_cdf,x,y,bounds=(0, [100, 20]))
                    
                    resiw = y- weibull_cdf(x, *poptw)
                    resie = y- exponetial_cdf(x, *popte)
                    resin = y- normal_cdf(x, *poptn)
                    resil = y- lognormal_cdf(x, *poptl)
                    # resig = y- logistic_cdf(x, *poptg)


                    ttw = weibull_cdf(36, *poptw)
                    tte = exponetial_cdf(36, *popte)
                    ttn = normal_cdf(36, *poptn)
                    ttl = lognormal_cdf(36, *poptl)
                    # ttg = logistic_cdf(36, *poptg)

                    
                    
                    # for j in range(len(tis_list)):
                        # ttw = weibull_cdf(tis_list[j], *poptw)
                        # tte = exponetial_cdf(tis_list[j], *popte)
                        # ttn = normal_cdf(tis_list[j], *poptn)
                        # ttl = lognormal_cdf(tis_list[j], *poptl)
                    
                    
                    
                    lt_r  = []
                    lt_r.append(r(resiw,y,ttw))
                    lt_r.append(r(resie,y,tte))
                    lt_r.append(r(resin,y,ttn))
                    lt_r.append(r(resil,y,ttl))
                    # lt_r.append(r(resig,y,ttg))
                    r_squared,ttvalue = zip(*lt_r)

                    # index, value = max(enumerate(r_squared), key=operator.itemgetter(1))
                    mid_value_index = [i for i, elem in enumerate(ttvalue) if elem > min(ttvalue) and elem < max(ttvalue)]
                    best_r2 = max([elem for i, elem in enumerate(r_squared) if i in mid_value_index])
                    index =[i for i, elem in enumerate(r_squared) if elem == best_r2][0]
            # ind, val = max(enumerate(ttvalue), key=operator.itemgetter(1))
            # plt.style.use('ggplot')
            # fig, axs = plt.subplots(2,2, figsize=(14, 8))
            # fig.subplots_adjust(hspace = .25, wspace=.1)
            # axs = axs.ravel()
            # plt.suptitle('The Best Distribution is ' + dists[index] + '\n' + 'F(36)=' + str(round(ttvalue[index],4)), fontsize=16)
            # axs[0].plot(xx,weibull_cdf(xx,*poptw),'r--',label='fit')
            # axs[1].plot(xx,exponetial_cdf(xx,*popte),'r--',label='fit')
            # axs[2].plot(xx,normal_cdf(xx,*poptn),'r--',label='fit')
            # axs[3].plot(xx,lognormal_cdf(xx,*poptl),'r--',label='fit')
            
            # for i in range(4):
                # axs[i].step(x,y,'b-',where='mid',label='data')
                # axs[i].set_title(dists[i])
                # axs[i].set_ylim([0, round(val*5)/5])
                # axs[i].text(30, val*0.05, r'$R^{2} = $' + str(round(r_squared[i],5)))
                # if i == index:
                    # axs[i].text(30, val*0.6, r'$\checkmark$',fontsize=32,color='red')
                    # # axs[i].text(-1, val*0.95, round(ttvalue[i],4),color='red')
                    # # axs[i].arrow(36, ttvalue[i], -37, 0, color='k',lw=0.3,ls='--')
            # plt.show()	
                
                    if index ==0:
                        fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist()
                        fcrpt['Model'] = 'Weibull' + ('_immature' if N < 7 else '')
                    elif index == 1:
                        fcrpt['Forecast_R1000'] = (exponetial_cdf(xx,*popte)*1000).tolist()
                        fcrpt['Model'] = 'Exponetial' + ('_immature' if N < 7 else '')
                    elif index == 2:
                        if max(y) > 0.03:
                            fcrpt['Forecast_R1000'] = (normal_cdf(xx,*poptn)*1000).tolist()
                            fcrpt['Model'] = 'Normal' + ('_immature' if N < 7 else '')
                        else:
                            model = LinearRegression()
                            # model = LogisticRegression()
                            model.fit(pd.DataFrame(x), pd.DataFrame(y))
                            yy = model.predict(pd.DataFrame(xx))*1000
                            fcrpt['Forecast_R1000'] = yy.ravel()
                            fcrpt['Model'] = 'Linear' + ('_immature' if N < 7 else '')
                            # fcrpt['Model'] = 'Linear-Logistic' + ('_immature' if N < 7 else '')					

                            # svr_rbf = SVR(kernel='rbf', C=0.1, gamma=1)
                            # svr_rbf.fit(pd.DataFrame(x), pd.DataFrame(y))
                            # yy = svr_rbf.predict(pd.DataFrame(xx))*1000
                            # fcrpt['Forecast_R1000'] = yy.ravel()
                            # fcrpt['Model'] = 'SVR' + ('_immature' if N < 7 else '')	
                    elif index == 3:
                        fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
                        fcrpt['Model'] = 'Lognormal' + ('_immature' if N < 7 else '')
                    # else:
                        # fcrpt['Forecast_R1000'] = (logistic_cdf(xx,*poptg)*1000).tolist()
                        # fcrpt['Model'] = 'Logistic' + ('_immature' if N < 7 else '')
                else:	
                    svr_rbf = SVR(kernel='rbf', C=0.1, gamma=1)
                    svr_rbf.fit(pd.DataFrame(x), pd.DataFrame(y))
                    yy = svr_rbf.predict(pd.DataFrame(xx))*1000         
                    if yy.max() < max(y)*1000:
                        fcrpt['Forecast_R1000'] = yy.ravel()*2	
                    else:
                        fcrpt['Forecast_R1000'] = yy.ravel()
                    fcrpt['Model'] = 'SVR'					
                            
            except Exception as e:
                # print(tuple(yy))
                # plt.figure(figsize=(14,8))
                # plt.step(x,y,'b-',where='mid')
                # plt.plot(xx, yy, 'r--')
                # plt.ylim([0, 0.01])
                # plt.xlim([0, 36])
                # plt.show()
                print (e)
                continue
            fcrpt['TIS'] = xx.tolist()
            fcrpt['MODEL YEAR'] = year
            fcrpt['IDX'] = ddf.loc[i, 'IDX']
            rpt = pd.merge(fcrpt, ndf[['IDX','MODEL YEAR','TIS','R1000','VEHICLES']],how='outer', on=['IDX','MODEL YEAR','TIS'])
            report = report.append(rpt)
            print(year,round((i+1)*100/len(ddf),1),'%, ',i+1,len(ddf))
    except Exception as e:
        print (e)
        continue
    reportall = reportall.append(report)

df_rpt = reportall.drop_duplicates()    
df = pd.read_csv('C:/jluo/Export/QBdb.CSV')
db = pd.merge(df_rpt, df[['INDEXS','QB','Vehicle Line Global','PART NUM BASE (CAUSL)','Base Part Description']],how='left', left_on = 'IDX', right_on = 'INDEXS') #same columns, on=['INDEXS']

db.sort_values(by=['IDX','MODEL YEAR','TIS']).to_csv('C:/jluo/Export/rpt_tis_ttl.CSV', encoding='utf-8',index=False,columns=['IDX','MODEL YEAR','TIS','VEHICLES','R1000','Forecast_R1000','Model','QB','Vehicle Line Global','PART NUM BASE (CAUSL)','Base Part Description'])

stop = timeit.default_timer()
print (round(stop - start,3),'s')