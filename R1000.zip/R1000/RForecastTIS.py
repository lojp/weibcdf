# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import heapq


year = 2017
# df = pd.read_csv('C:/jluo/Export/TISREPtest.CSV', encoding='utf-8')
# df = pd.read_csv('C:/jluo/Export/TISREPTT.CSV', encoding='utf-8')
# ndf = df[(df['MODEL YEAR'] == year) & (df['PART NUM BASE (CAUSL)'] == 'TOTAL') & (df['PROD_MONTH'].isnull())]
df =  pd.read_excel('C:/Users/jluo27/Desktop/R.xlsx', sheet_name='Sheet3')
ddf = pd.pivot_table(df,index=['IDX'], values=['TIS'],aggfunc='max').reset_index()
ddf.columns = ['IDX','TIS_MAX']
newdf = pd.merge(ddf, df.drop(['MODEL YEAR'],axis=1) ,how='left', on=['IDX'])



dists = ['Weibull','Exponetial','Normal','Lognormal']
distnames = ['weibull_cdf','Exponetial_cdf','Normal_cdf','Lognormal_cdf']
reportall= pd.DataFrame()

mis = 84
def r(x,y,z):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot),z


for i in range(len(ddf)):
    ndf = newdf[newdf['IDX'] == ddf.loc[i, 'IDX']]
    N = ddf.loc[i, 'TIS_MAX']
    
    ydata1 = list(ndf['R1000'][1:N+1]/1000)
    if max(ydata1) > 3 * heapq.nlargest(2,ydata1)[1]:
        N = N-1
    ydata = list(ndf['R1000'][1:N+1]/1000)
    x = ar(range(1,N+1))
    y = ar(ydata)
    xx = ar(range(1,mis+1))
    # rpr = ar(list(ndf['REPAIRS'][1:N+1]))    
    
    report = pd.DataFrame() 


    # print(y)

    if max(y) > 0.003: 	
        poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
        popte,pcove =  curve_fit(exponetial_cdf,x,y, bounds=(0, [5, 100]))
        poptn,pcovn =  curve_fit(normal_cdf,x,y)
        poptl,pcovl =  curve_fit(lognormal_cdf,x,y)

        resiw = y- weibull_cdf(x, *poptw)
        resie = y- exponetial_cdf(x, *popte)
        resin = y- normal_cdf(x, *poptn)
        resil = y- lognormal_cdf(x, *poptl)

        ttw = weibull_cdf(mis, *poptw)
        tte = exponetial_cdf(mis, *popte)
        ttn = normal_cdf(mis, *poptn)
        ttl = lognormal_cdf(mis, *poptl)

        lt_r  = []
        lt_r.append(r(resiw,y,ttw))
        lt_r.append(r(resie,y,tte))
        lt_r.append(r(resin,y,ttn))
        lt_r.append(r(resil,y,ttl))
        r_squared,ttvalue = zip(*lt_r)

        indx, value = max(enumerate(r_squared), key=operator.itemgetter(1))
        ind, val = max(enumerate(ttvalue), key=operator.itemgetter(1))

        plt.style.use('ggplot')
        fig, axs = plt.subplots(2,2, figsize=(14, 8))
        fig.subplots_adjust(hspace = .25, wspace=.1)
        axs = axs.ravel()
        plt.suptitle('Different Distributions', fontsize=20)
        plt.suptitle('The Best Distribution is ' + dists[indx] + '\n' + 'F(36)=' + str(round(ttvalue[indx],4)), fontsize=16)   #显示best
        axs[0].plot(xx,weibull_cdf(xx,*poptw),'r--',label='fit')
        axs[1].plot(xx,exponetial_cdf(xx,*popte),'r--',label='fit')
        axs[2].plot(xx,normal_cdf(xx,*poptn),'r--',label='fit')
        axs[3].plot(xx,lognormal_cdf(xx,*poptl),'r--',label='fit')
        
        # for i in range(4):
            # axs[i].step(x,y,'b-',where='mid',label='data')
            # axs[i].set_title(dists[i])
            # axs[i].set_ylim([0, round(val*5)/5])
            # axs[i].text(30, val*0.05, r'$R^{2} = $' + str(round(r_squared[i],5)))
            # # if i == indx:  #加沟
                # # axs[i].text(30, 0.6, r'$\checkmark$',fontsize=32,color='red')
                # # axs[i].text(-1, val*0.95, round(ttvalue[i],4),color='red')
                # # axs[i].arrow(36, ttvalue[i], -37, 0, color='k',lw=0.3,ls='--')
        # # plt.show()	
        indx =0
        fcrpt = pd.DataFrame() 
        
        # fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist() #*************manual select**************
        # fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
        if indx ==0:
            fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist()
            fcrpt['Model'] =  'weibull'
        elif indx == 1:
            fcrpt['Forecast_R1000'] = (exponetial_cdf(xx,*popte)*1000).tolist()
            fcrpt['Model'] =  'exponetial'
        elif indx == 2:
            fcrpt['Forecast_R1000'] = (normal_cdf(xx,*poptn)*1000).tolist()
            fcrpt['Model'] =  'normal'
        else:
            fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
            fcrpt['Model'] =  'lognormal'
        fcrpt['TIS'] = xx.tolist()
        fcrpt['IDX'] = ddf.loc[i, 'IDX']
        rpt = pd.merge(fcrpt, ndf[['IDX','TIS','R1000']],how='outer', on=['IDX','TIS'])
        report = report.append(rpt)
        print(year,round((i+1)*100/len(ddf),1),'%, ',i+1,len(ddf))
    reportall = reportall.append(report)
df_rpt = reportall.drop_duplicates()    
df_rpt.sort_values(by=['IDX','TIS']).to_csv('C:/Users/jluo27/Desktop/rpt_' + str(mis) +'.CSV', encoding='utf-8',index=False,columns=['IDX','TIS','R1000','Forecast_R1000','Model'])
# print(reportall)
# else:
    # plt.step(x,y,'b-',where='mid')
    # plt.ylim([0, 0.2])
    # plt.xlim([0, 36])
    # plt.show()

# for i in range(4):
# popt,pcov =  curve_fit(d[0],x,y, bounds=(0, [5, 100]))
# resi = y- d[0](x, *popt)
# ttw = d[0](36, *popt)
# print(d[0])