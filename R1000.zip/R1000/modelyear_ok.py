# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import timeit
start = timeit.default_timer()

year = 2017
# names = ['MATRIX','PROD_MONTH','TIS','R1000','REPAIRS','VEHICLES','COSTS','CPU','CPR','MODEL YEAR','Vehicle Line Global','PART NUM BASE (CAUSL)','LOGIC','K']
df = pd.read_csv('C:/jluo/Export/CPUDAT.CSV',encoding='utf-8')
# df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df = df[df['MODEL YEAR'] == year]
df['VL'] = df['Vehicle Line Global']
df['INDEXS'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)

temp_df = df[df['TIS'] == 0]
temp_df = temp_df[temp_df['VEHICLES'] > 100]

df = df[df.INDEXS.isin(temp_df.INDEXS)]   # df = df[~df.INDEXS.isin(temp_df.INDEXS)] #交叉查询结果

ddf = pd.pivot_table(df,index=['INDEXS'], values=['TIS'],aggfunc='max').reset_index()
ddf.columns = ['INDEXS','TIS_MAX']
newdf = pd.merge(ddf, df.drop(['PROD_MONTH','CPU','CPR','LOGIC'],axis=1) ,how='left', on=['INDEXS'])


def r(x,y,z):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot),z


dists = ['Weibull','Exponetial','Normal','Lognormal']
report = pd.DataFrame() 
for i in range(len(ddf)):
# for i in range(1000):
    try:
        ndf = newdf[(newdf['MODEL YEAR'] == year) & (newdf['INDEXS'] == ddf.loc[i, 'INDEXS'])]
        N = ddf.loc[i, 'TIS_MAX']
        ydata = list(ndf['R1000'][1:N+1]/1000)
        x = ar(range(1,N+1))
        y = ar(ydata)
        xx = ar(range(1,37))
        rpr = ar(list(ndf['REPAIRS'][1:N+1]))
    

# def weibull_cdf(x, a, b):
    # return 1 - np.exp(-(x / b) ** a)

# def exponetial_cdf(x, lambd, a=0):
    # """CDF of exponetial distribution."""
    # return 1 - np.exp(-lambd*x) + a
	
# def normal_cdf(x, mu, sigma):
    # return 0.5*sp.erfc((mu-x)/(sigma*np.sqrt(2.0)))

# def lognormal_cdf(x,mean,sigma):
    # z    = (np.log(x)-mean)/float(sigma)
    # y  = 0.5*(sp.erfc(-z/np.sqrt(2)))
    # return y

	
        fcrpt = pd.DataFrame() 		
        poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
        popte,pcove =  curve_fit(exponetial_cdf,x,y, bounds=(0, [5, 100]))
        poptn,pcovn =  curve_fit(normal_cdf,x,y)
        poptl,pcovl =  curve_fit(lognormal_cdf,x,y)
			
        resiw = y- weibull_cdf(x, *poptw)
        resie = y- exponetial_cdf(x, *popte)
        resin = y- normal_cdf(x, *poptn)
        resil = y- lognormal_cdf(x, *poptl)

        ttw = weibull_cdf(36, *poptw)
        tte = exponetial_cdf(36, *popte)
        ttn = normal_cdf(36, *poptn)
        ttl = lognormal_cdf(36, *poptl)

        lt_r  = []
        lt_r.append(r(resiw,y,ttw))
        lt_r.append(r(resie,y,tte))
        lt_r.append(r(resin,y,ttn))
        lt_r.append(r(resil,y,ttl))
        r_squared,ttvalue = zip(*lt_r)

        index, value = max(enumerate(r_squared), key=operator.itemgetter(1))
    # ind, val = max(enumerate(ttvalue), key=operator.itemgetter(1))
    # plt.style.use('ggplot')
    # fig, axs = plt.subplots(2,2, figsize=(14, 8))
    # fig.subplots_adjust(hspace = .25, wspace=.1)
    # axs = axs.ravel()
    # plt.suptitle('The Best Distribution is ' + dists[index] + '\n' + 'F(36)=' + str(round(ttvalue[index],4)), fontsize=16)
    # axs[0].plot(xx,weibull_cdf(xx,*poptw),'r--',label='fit')
    # axs[1].plot(xx,exponetial_cdf(xx,*popte),'r--',label='fit')
    # axs[2].plot(xx,normal_cdf(xx,*poptn),'r--',label='fit')
    # axs[3].plot(xx,lognormal_cdf(xx,*poptl),'r--',label='fit')
    
    # for i in range(4):
        # axs[i].step(x,y,'b-',where='mid',label='data')
        # axs[i].set_title(dists[i])
        # axs[i].set_ylim([0, round(val*5)/5])
        # axs[i].text(30, val*0.05, r'$R^{2} = $' + str(round(r_squared[i],5)))
        # if i == index:
            # axs[i].text(30, val*0.6, r'$\checkmark$',fontsize=32,color='red')
            # # axs[i].text(-1, val*0.95, round(ttvalue[i],4),color='red')
            # # axs[i].arrow(36, ttvalue[i], -37, 0, color='k',lw=0.3,ls='--')
    # plt.show()	
        
        if index ==0:
            fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist()
            fcrpt['Model'] = 'Weibull' + ('_immature' if N < 7 else '')
        elif index == 1:
            fcrpt['Forecast_R1000'] = (exponetial_cdf(xx,*popte)*1000).tolist()
            fcrpt['Model'] = 'Exponetial' + ('_immature' if N < 7 else '')
        elif index == 2:
            fcrpt['Forecast_R1000'] = (normal_cdf(xx,*poptn)*1000).tolist()
            fcrpt['Model'] = 'Normal' + ('_immature' if N < 7 else '')
        else:
            fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
            fcrpt['Model'] = 'Lognormal' + ('_immature' if N < 7 else '')	
    except:
        # print(tuple(yy))
        # plt.figure(figsize=(14,8))
        # plt.step(x,y,'b-',where='mid')
        # plt.plot(xx, yy, 'r--')
        # plt.ylim([0, 0.01])
        # plt.xlim([0, 36])
        # plt.show()
        continue
    fcrpt['TIS'] = xx.tolist()
    fcrpt['MODEL YEAR'] = year
    fcrpt['INDEXS'] = ddf.loc[i, 'INDEXS']
    rpt = pd.merge(fcrpt, ndf[['INDEXS','MODEL YEAR','TIS','R1000','VEHICLES']],how='outer', on=['INDEXS','MODEL YEAR','TIS'])
    report = report.append(rpt)
    print(round(i*100/len(ddf),1),'%, ',len(ddf),i)

report.sort_values(by=['INDEXS','TIS']).to_csv('C:/jluo/Export/rpt_tis' + str(year) + '.CSV', encoding='utf-8',index=False,columns=['INDEXS','MODEL YEAR','TIS','VEHICLES','R1000','Forecast_R1000','Model'])
stop = timeit.default_timer()
print (round(stop - start,3),'s')