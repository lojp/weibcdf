# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVR
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import timeit
import heapq
start = timeit.default_timer()


df = pd.read_csv('C:/jluo/Export/rpt_tis2017.CSV')
df = df[df['INDEXS']=='ED_N400K01']

x = df['TIS']
y = df['R1000']/1000
yy = df['Forecast_R1000']/1000

plt.style.use('ggplot')
plt.figure(figsize=(9,6))
plt.step(x,y,'b-',where='mid')
plt.plot(x, yy, 'r--')
plt.ylim([0, 1])
plt.xlim([0, 36])
plt.show()
# stop = timeit.default_timer()
# print (round(stop - start,3),'s')