# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")


df = pd.read_csv('C:/jluo/Export/CLAIMLI.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
print(df.head(5))

#Assembly Plant Vehicle Line WERS

# stop = timeit.default_timer()
# print (slection,'tis',round(stop - start,3),'s')
	
