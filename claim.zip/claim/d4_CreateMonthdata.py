# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
import warnings
import timeit
import os
import sys
import shutil
start = timeit.default_timer()
warnings.simplefilter("ignore")

# mydir= raw_input("Enter directory name : ")
mydir = 'C:/jluo/data/New/kk/'

if os.path.exists(mydir):
    shutil.rmtree(mydir)
os.makedirs(mydir)
# os.makedirs(mydir, exist_ok=True)

dmc = pd.read_csv('C:/jluo/Export/Monthly/MonthlyCLAIMLIS.CSV', encoding='utf-8')
dmt = pd.read_csv('C:/jluo/Export/Monthly/MonthlyTISREP.CSV', encoding='utf-8')
dwc = pd.read_csv('C:/jluo/Export/Monthly/WCCCLAIMLIS.CSV', encoding='utf-8')
dwt = pd.read_csv('C:/jluo/Export/Monthly/WCCTISREP.CSV', encoding='utf-8')


dp = pd.read_csv('C:/jluo/Export/Monthly/Partlist.CSV', encoding='utf-8')
slsdt = pd.read_csv('C:/jluo/Export/Monthly/VVOLUME.CSV', encoding='utf-8')
slsdf = slsdt.groupby(['Vehicle Line Global', 'Production Month','Country Sold'], as_index=False)['VEHICLES'].agg('sum')
dp = dp[dp['item'].str.contains('Controller')]   #check special workstream
# dp = dp[dp['Type']==1]   #check special workstream

# report = pd.DataFrame() 
for i in range(len(dp)):
# for i in range(2):
    try:
        mylist44 = (dp.iloc[i,2]).split(',') #part
        mylist39 = (dp.iloc[i,2]).replace('WCC','').split(',') #wcc
        # # mylist35 = (dp.iloc[i,3]).split(',') #VL
        dtlist1 = pd.DataFrame(np.array(mylist44).reshape(-1), columns = ['Part'])
        # # dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
        dtlist3 = pd.DataFrame(np.array(mylist39).reshape(-1), columns = ['WCC'])
		
        if dp.iloc[i,0] ==2:
	        mylist35 = (dp.iloc[i,3]).split(',')
	        dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
	        dff = dmc[dmc.iloc[:,44].isin(mylist44)]
	        clmlist = dff[dff.iloc[:,35].isin(mylist35)]
	        dkk = dmt[dmt.iloc[:,7].isin(mylist44)]
	        dk = dkk[dkk.iloc[:,6].isin(mylist35)]
	        dtlist3 = dtlist3[0:0]
	        
        elif dp.iloc[i,0] ==1:
	        mylist35 = (dp.iloc[i,3]).split(',')
	        dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
	        dff = dwc[dwc.iloc[:,39].isin(mylist39)]
	        clmlist = dff[dff.iloc[:,35].isin(mylist35)]
	        dkk = dwt[dwt.iloc[:,7].isin(mylist39)]
	        dk = dkk[dkk.iloc[:,6].isin(mylist35)]
	        dtlist1 = dtlist1[0:0]
	        
        elif dp.iloc[i,0] ==0:	
	        clmlist = dmc[dmc.iloc[:,44].isin(mylist44)]
	        dk = dmt[dmt.iloc[:,7].isin(mylist44)]
	        dtlist2 = pd.DataFrame({'Vehicle Line Global' : []})
	        dtlist3 = pd.DataFrame({'WCC' : []})
	        
        else:
	        pass
        

        clsdt = pd.pivot_table(clmlist,index=['Vehicle Line Global','Country Sold'], values=['VIN'],aggfunc='count').reset_index()
        slsdt = pd.merge(slsdf, clsdt[['Vehicle Line Global','Country Sold']],how='inner', on=['Vehicle Line Global','Country Sold']) #bug
        
        clscount = pd.pivot_table(clmlist,index=['Vehicle Line Global','Production Month'], values=['VIN'],aggfunc='count').reset_index()
        slscount = pd.pivot_table(slsdt,index=['Vehicle Line Global','Production Month'], values=['VEHICLES'],aggfunc='sum').reset_index()

        tis1 = pd.pivot_table(dk,index=['Vehicle Line Global','PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
        tb = tis1[tis1['TIS']==0]
        tb1 = tb[tb['VEHICLES']>2]
        tisdb = pd.merge(tis1, tb1[['Vehicle Line Global','PROD_MONTH']],how='inner', on=['Vehicle Line Global','PROD_MONTH'])
      
        tis2 = pd.pivot_table(tis1,index=['PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
        tis2['Vehicle Line Global'] = 'TOTAL'
        
        vldf = pd.pivot_table(clmlist,index=['Vehicle Line Global','Vehicle Line Global Desc'], values=['Total Cost Gross'],aggfunc='sum').reset_index()
        vldf['vl'] = vldf['Vehicle Line Global'] + ' - ' + vldf['Vehicle Line Global Desc']
        vldf = vldf.sort_values(by=['Total Cost Gross'], ascending=0)   #latest version is sort_values 
		
        tis = tisdb.append(tis2, ignore_index=True)
        tis['PROD_MONTH'] = pd.to_datetime(tis['PROD_MONTH'])  #时间修改
        writer = pd.ExcelWriter(mydir + dp.iloc[i,1] + '.xls', engine='xlsxwriter')
        dt1 = pd.DataFrame(clmlist)	
        dt1.to_excel(writer, sheet_name='claimlist1',index=False, encoding='utf-8')
        # report = report.append(dt1)
		
		
        dt2 = pd.DataFrame(tis)
        cols = ['Vehicle Line Global','PROD_MONTH','TIS','REPAIRS','COSTS','VEHICLES']
        dt2.to_excel(writer, sheet_name='TIS_REPORT',index=False,columns=cols, encoding='utf-8')		

        vldf.to_excel(writer, sheet_name='vllist',index=False, columns=['vl','Total Cost Gross'])
        clscount.to_excel(writer, sheet_name='TISRvolume',index=False, encoding='utf-8')
        slscount.to_excel(writer, sheet_name='TISVvolume',index=False, encoding='utf-8')

        dtlist1.to_excel(writer, sheet_name='LIST_PARTS',index=False, encoding='utf-8')	
        dtlist2.to_excel(writer, sheet_name='LIST_VL',index=False, encoding='utf-8')
        dtlist3.to_excel(writer, sheet_name='LIST_OPTION',index=False, encoding='utf-8')        
        print(i+1)
        writer.save()

    except:
        # print('4')
        continue

# report.to_csv('C:/jluo/Export/checklist.CSV', encoding='utf-8',index=False)
stop = timeit.default_timer()
print (round(stop - start,3),'S',round((stop - start)/(len(dp)+1),3),'S')