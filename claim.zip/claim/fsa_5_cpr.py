# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
import warnings
import timeit
import os
import sys
import shutil
from datetime import date, timedelta, datetime
from dateutil.relativedelta import relativedelta
import win32com.client
from collections import OrderedDict
start = timeit.default_timer()
warnings.simplefilter("ignore")
dates = [str(date.today() + relativedelta(months=-4)), str(date.today().replace(day=1) - timedelta(days=1))]
begin, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_l4m = list(OrderedDict(((begin + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - begin).days)).keys())

mydir = 'C:/jluo/data/New/kk/'

if os.path.exists(mydir):
    shutil.rmtree(mydir)
os.makedirs(mydir)
# os.makedirs(mydir, exist_ok=True)

dmc = pd.read_csv('C:/jluo/Export/Monthly/FSACPR.CSV', encoding='utf-8')
dp = pd.read_excel('C:/jluo/Export/Monthly/temp.xlsx', sheetname='Sheet1')
slsdt = pd.read_csv('C:/jluo/Export/Monthly/VVOLUME.CSV', encoding='utf-8')
slsdf = slsdt.groupby(['Vehicle Line Global', 'Production Month','Country Sold'], as_index=False)['VEHICLES'].agg('sum')
# dp = dp[dp['item'].str.contains('4C')]   #check special workstream
# dp = dp[dp['Type']==2]   #check special workstream
# dp = dp[dp['item'].str.contains('GQB5')] 

excelfile = ['CPR']
month_type_list = ['Load Month','Production Month','Repair Month']
cols= ['Label','Country Repaired','month_type','Month','Total Cost Gross','VIN','CPR','LHPR','LCPR','MPR']

for i in range(len(dp)):
# for i in range(2):
    try:        
        df_raw_cpr = pd.DataFrame()
        mylist_part = dp.iloc[i,2].split("!@#$%^&*")
        clmlist = dmc[dmc.iloc[:,16].isin(mylist_part)]
        dtlist1 = pd.DataFrame(np.array(mylist_part).reshape(-1), columns = ['Part'])  
        dtlist2 = pd.DataFrame({'Vehicle Line Global' : []})
        dtlist3 = pd.DataFrame({'WCC' : []})
        dt_title = pd.DataFrame({'Label' : [],'VL_long' : [],'PART_long' : []})
        dt_next = pd.DataFrame({'Project_12' : []})
        # df = clmlist[clmlist['Load Month'].isin(list_l4m)]
        df_lm_l4m = pd.pivot_table(clmlist[clmlist['Load Month'].isin(list_l4m)],index=['Production Month'], values=['VIN'],aggfunc='count').reset_index()
        df_lhr = pd.pivot_table(clmlist,index=['Labor Hours'], values=['VIN'],aggfunc='count').reset_index()
        df_lhr['month_type'] = 'SP'
        df_lhr['Month'] = ''
        
        for j in range(len(month_type_list)):
            df_raw_cty = pd.pivot_table(clmlist,index=['Country Repaired',month_type_list[j]], 
                                    values=['Total Cost Gross','VIN','Labor Hours','Labor Cost','Material Cost'],
                                    aggfunc={'Total Cost Gross':np.sum,
                                            'VIN':'count',
                                            'Labor Hours':np.sum,
                                            'Labor Cost':np.sum,
                                            'Material Cost':np.sum}).reset_index()
            df_raw_all = pd.pivot_table(clmlist,index=[month_type_list[j]], 
                                    values=['Total Cost Gross','VIN','Labor Hours','Labor Cost','Material Cost'],
                                    aggfunc={'Total Cost Gross':np.sum,
                                            'VIN':'count',
                                            'Labor Hours':np.sum,
                                            'Labor Cost':np.sum,
                                            'Material Cost':np.sum}).reset_index()
            df_raw_all['Country Repaired'] ='TOTAL'
            df_raw = df_raw_cty.append(df_raw_all)
            df_raw['month_type'] = month_type_list[j][0]+'M'
            df_raw = df_raw.rename(index=str, columns={month_type_list[j]: 'Month'})
            df_raw_cpr = df_raw_cpr.append(df_raw)
            
        df_raw_cpr['CPR']=df_raw_cpr['Total Cost Gross']/df_raw_cpr['VIN']
        df_raw_cpr['LHPR']=df_raw_cpr['Labor Hours']/df_raw_cpr['VIN']
        df_raw_cpr['LCPR']=df_raw_cpr['Labor Cost']/df_raw_cpr['VIN']
        df_raw_cpr['MPR']=df_raw_cpr['Material Cost']/df_raw_cpr['VIN']
        df_raw_cpr['Label']=dp.iloc[i,1]

        df_raw_cpr = df_raw_cpr.drop(columns=['Labor Cost', 'Labor Hours','Material Cost'])

        
        writer = pd.ExcelWriter(mydir + 'cpr.xls', engine='xlsxwriter')        
        df_raw_cpr.to_excel(writer, sheet_name='TBL_CPR_DATASET',index=False,columns=cols, encoding='utf-8')
        df_lm_l4m.to_excel(writer, sheet_name='Add_L4M',index=False, encoding='utf-8')
        df_lhr.to_excel(writer, sheet_name='Add_SP',index=False,columns=['month_type','Month','Labor Hours','VIN'], encoding='utf-8')
        
        dt_title.to_excel(writer, sheet_name='TBL_CPR_CRITERIA',index=False, encoding='utf-8')
        dt_next.to_excel(writer, sheet_name='ADD_NEXT',index=False, encoding='utf-8')
        
        dtlist1.to_excel(writer, sheet_name='LIST_PARTS',index=False, encoding='utf-8')	
        dtlist2.to_excel(writer, sheet_name='LIST_VL',index=False, encoding='utf-8')
        dtlist3.to_excel(writer, sheet_name='LIST_OPTION',index=False, encoding='utf-8')        
        writer.save()
        # newpath = 'C:/jluo/data/New/report/' + dp.iloc[i,1] + '/'
        # if not os.path.exists(newpath):
            # os.makedirs(newpath)

        for j in range(len(excelfile)):
            xl=win32com.client.Dispatch("Excel.Application")
            # xl.Application.Visible = True
            shutil.copy('C:/jluo/tool/MONTHLY/' + excelfile[j] + '_py.xls','C:/jluo/data/template/' + excelfile[j] + '_py.xls')
            wb = xl.Workbooks.Open(Filename='C:/jluo/data/template/' + excelfile[j] + '_py.xls')
            xl.Application.Run("Module1.A_generate_rpt")
            xl.Application.ActiveWorkbook.SaveAs('C:\\jluo\\data\\New\\report\\' + excelfile[j] + '-' + dp.iloc[i,1] + '.xls') 
            wb.Close(SaveChanges=True)
            xl.Application.Quit() # Comment this out if your excel script closes
            del xl
        print (i+1, ', ', round(100*(i+1)/len(dp),3),'%, -->', dp.iloc[i,1])    
    except:
        # print('4')
        continue

    
stop = timeit.default_timer()
print ('Total:', round(stop - start,3),'s, Each workstream is',round((stop - start)/len(dp),3),'s')
