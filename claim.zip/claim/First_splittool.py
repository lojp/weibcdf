
import pandas as pd
import numpy as np
import re
import warnings
import timeit
# from dduplicate import *
import os
warnings.simplefilter("ignore")
start = timeit.default_timer()
orig_df = pd.read_csv('C:/jluo/Export/Monthly/Partlist.CSV')

# print(orig_df[orig_df['item'] == 'GQB5_AC Control Bezel--CD391'])
def faster_p(df):
    df["QB"] = df['item'].str.split('_').str[0]
    df["Label"] = df['item'].str.split('_').str[1]
    s = df['PartSum'].str.split(',', expand=True).stack().astype('str')
    i = s.index.get_level_values(0)
    df2 = df.loc[i].copy()
    df2["PartSum"] = s.values
    df2 = df2.drop(['Type','vl','QB','item'],axis=1).dropna(axis=0,how='any')
    df2 = df2[df2['PartSum'].map(len)>1]
    return df2[~df2['PartSum'].str.contains('EXCEPT')]

def faster_v(df):
    df["QB"] = df['item'].str.split('_').str[0]
    df["Label"] = df['item'].str.split('_').str[1]
    s = df['vl'].str.split(',', expand=True).stack()
    i = s.index.get_level_values(0)
    df2 = df.loc[i].copy()
    df2["vl"] = s.values
    df2 = df2.drop(['Type','PartSum','QB','item'],axis=1).dropna(axis=0,how='any')
    return df2

def faster_item(df):
    df2 = df.copy()
    df2["QB"] = df['item'].str.split('_').str[0]
    df2["Label"] = df['item'].str.split('_').str[1]
    df2 = df2.drop(['Type','PartSum','vl','item'],axis=1).dropna(axis=0,how='any')
    return df2
	
# print(faster_p(orig_df).head(10))
# print(faster_v(orig_df).head(10))


# df = faster_p(orig_df)
# nd = df[df['PartSum'].map(len)>1]
# print(nd[nd['item']=='GQB4_4C Door Mirror - UP375 Everest&Endeavour'])
# faster_p(orig_df).to_csv('C:/jluo/Export/Monthly/p.CSV', encoding='utf-8',index=False,columns=['item','PartSum'])
# faster_v(orig_df).to_csv('C:/jluo/Export/Monthly/v.CSV', encoding='utf-8',index=False,columns=['item','vl'])


writer = pd.ExcelWriter('C:/jluo/tool/AP_monthlydata.xls', engine='xlsxwriter')
faster_p(orig_df).to_excel(writer, sheet_name='Parts',index=False, encoding='utf-8', columns=['Label','PartSum'])
faster_v(orig_df).to_excel(writer, sheet_name='VLs',index=False, encoding='utf-8', columns=['Label','vl'])
faster_item(orig_df).to_excel(writer, sheet_name='Item',index=False, encoding='utf-8', columns=['Label','QB'])
writer.save()

stop = timeit.default_timer()
print (round(stop - start,3),'s')