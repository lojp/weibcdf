# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp

	 
df = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['WCC_Code'] = df['WCC'].str.split(' - ').str[0]
df['QB'] = df['QB Global Sub Group'].str[:4]

# df = df[(df['PART NUM BASE (CAUSL)']=='10849')]
# df = df[df['PART NUM BASE (CAUSL)'].str.contains('782')]
# df = df[(df['PART NUM BASE (CAUSL)']=='13008') | (df['PART NUM BASE (CAUSL)']=='13009') ]
# df = df[df['QB Global Sub Group'].str.contains('GQB5')]
# df = df[df['VFG'].str.contains('V03')]
df = df[df['Vehicle Line Global'].str.contains('NAUTILUS')]
# df = df[df['VL']=='ZB']
# df = df[df['WCC_Code']=='7A01']
# df = df[df['Country Repaired'].str.contains('AUS')]
# df = df[(df['PART NUM BASE (CAUSL)']=='3F830') & (df['VL']=='K3')]
# df = df[df['Load Month'].str.contains('2017')]
# df = df[df['QB']=='GQB5']


# print(df.REPAIRS.sum(),df.COSTS.sum()/12)
ttl_df = pd.pivot_table(df,index=['Load Month'], values=['COSTS','REPAIRS'],aggfunc='sum').reset_index()
ttl_df['CPR'] =ttl_df.COSTS/ttl_df.REPAIRS

c_df = pd.pivot_table(df,index=['QB'], values=['COSTS'],aggfunc='sum').reset_index()
c_df['Percent'] = c_df.iloc[:, 1:].apply(lambda x: x / x.sum())
# # c_df['Percent'] = c_df['Percent'].apply(lambda x: "{0:.2f}%".format(x*100))
# # c_df['percentage'] = (c_df / c_df.groupby(['Country Repaired']).transform(sum))['COSTS']  # each group
c_df = c_df.sort_values(by=['COSTS'], ascending=0)
c_df['QB'] = np.where(c_df['Percent']>0.02, c_df['QB'], '')


v_df = pd.pivot_table(df,index=['Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
v_df['Percent'] = v_df.iloc[:, 1:].apply(lambda x: x / x.sum())
v_df = v_df.sort_values(by=['COSTS'], ascending=0)
v_df['vl'] = np.where(v_df['Percent']>0.02, v_df['Vehicle Line Global'].str.split(' - ').str[1], '')

my_xticks = ttl_df['Load Month']
y1 = ttl_df['COSTS']
y2 = ttl_df['CPR']
x = np.arange(len(my_xticks))


# # plt.style.use('ggplot')
# fig = plt.figure(figsize=(10,6))
# plt.xticks(x, my_xticks,rotation=90, fontsize=7)
# plt.plot(x,y,'r-',label='Costs')
# plt.plot(x,y2,'b--',label='CPR')
# plt.ylim(ymin=0)
# # plt.ylabel("Cumulative density")
# # plt.xlabel("TIS")
# # plt.title('lod', fontsize=16)		 
# plt.legend()
# plt.show()

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
plt.suptitle('AP CHART FOR ALL QBs', fontsize=15,fontweight='bold')
ax1.set_xlabel('Load Month')
ax1.set_ylabel('warranty spends')
lns1 = ax1.plot(x, y1, 'C1o-',label = 'Warranty spends')
ax1.set_ylim(ymin=0)
ax1.set_xticks(x)
ax1.set_xticklabels(my_xticks, rotation=90, fontsize=7)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
ax2.set_ylabel('CPR')  # we already handled the x-label with ax1
lns2 =ax2.plot(x, y2, '*--',label = 'CPR')
ax2.set_ylim(ymin=0)

lns = lns1+lns2
labs = [l.get_label() for l in lns]
ax1.legend(lns, labs, loc=0)


def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data

qb= c_df['COSTS']
c_labels = c_df['QB']
ax3 = fig.add_subplot(234)
ax3.pie(qb, labels=c_labels, autopct=autopct_more_than_1)



vl = v_df['COSTS']
v_labels = v_df['vl']
ax4 = fig.add_subplot(236)
ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_1)


fig.tight_layout() 
fig.savefig('C:/Users/jluo27/Desktop/AP_all.png')
plt.show()