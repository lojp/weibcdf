# -*- coding: utf-8 -*-
"""
must use 64bit to open ODBC  'Ctrl + Shift + F1'
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import win32api,time
from win32com.client import Dispatch
import timeit
start = timeit.default_timer()


strDbName = 'C:\jluo\Monthlydata.mdb'
ac = Dispatch("Access.Application")
ac.Visible = True
ac.OpenCurrentDatabase(strDbName)
objDB = ac.CurrentDb()
ac.DoCmd.RunMacro('Macro1')
ac.DoCmd.CloseDatabase
ac.Application.Quit()
del objDB

stop = timeit.default_timer()
print (round(stop - start,3),'s')