# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""

import csv
import numpy as np
import pandas as pd
import os
import timeit

mypath = 'C:/Panda/CSV/'
os.chdir(mypath)

# cols = ['Group_NO', 'Site', 'Index', 'No', 'Suffix', 'Country', 'PPF_PPNO', 'GPF_NPNO', 'DESC', 'BPNO', 
        # 'GPF_INVY_STS', 'Status', 'WCC_CD', 'HVY_REPL_NPNO', 'PRC_REPL_BY_NPNO', 'HVY_EPNO', 'HVY_FINIS_PNO', 
        # 'VDR_CD', 'VDR_NAME', 'VDR_COUNTRY', 'APP_VLN_Code_1', 'APP_VLN_1', 'APP_VLN_Code_2', 'APP_VLN_2', 'APP_VLN_Code_3', 'APP_VLN_3', 
        # 'Index_backup', 'CST_COST_LOCAL', 'CST_COST', 'PRC_LIST', 'CST_MATL', 'CST_DUTY', 'CST_FRT', 'CST_PKG', 'CST_LBR', 
        # 'DIST_Price', 'WHLR_Price', 'DLR_Price', 'FSCD_Margin', 'Margin_FRT_ex', 'FSCD_Margin_OLD', 
        # 'OLD_PRC_TIME1', 'OLD_PRC_TIME2', 'OLD_PRC_LIST1', 'OLD_PRC_LIST2', 'OLD_CST_TIME1', 'OLD_CST_TIME2', 
        # 'OLD_CST_COST1', 'OLD_CST_COST2', 'OLD_CST_MATL1', 'OLD_CST_MATL2', 
        # 'DIST_Price_Proposed', 'WHLR_Price_Proposed', 'DLR_Price_Proposed', 'PRC_LIST_Proposed', 
        # 'SPHA', 'SPHA_Proposed', 'BreakEven_Rate', 'Cut-off_Rate', 'SL12M', 'SL6M', 'SL3M', 'WL12M', 'WL6M', 'WL3M',
        # 'S1701', 'S1702', 'S1703', 'S1704', 'S1705', 'S1706', 'S1707', 'S1708', 'S1709', 'S1710', 'S1711', 'S1712', 
        # 'S1801', 'S1802', 'S1803', 'S1804', 'S1805', 'S1806', 'S1807', 'S1808', 'S1809', 'S1810', 'S1811',   
        # 'W1701', 'W1702', 'W1703', 'W1704', 'W1705', 'W1706', 'W1707', 'W1708', 'W1709', 'W1710', 'W1711', 'W1712', 
        # 'W1801', 'W1802', 'W1803', 'W1804', 'W1805', 'W1806', 'W1807', 'W1808', 'W1809', 'W1810', 'W1811']


# df_group = pd.read_csv('group.csv', encoding='latin1')
# df_price = pd.read_csv('price.csv', encoding='utf-8')
# df_sales = pd.read_csv('sales.csv', encoding='utf-8')
# df_warr = pd.read_csv('warr.csv', encoding='utf-8')

# df1 = pd.merge(df_group, df_price.drop(['Suffix'],axis=1),how='left', on=['Index'])
# df2 = pd.merge(df1, df_sales,how='left', on=['Index'])
# new_df = pd.merge(df2, df_warr,how='left', on=['Index'])
# new_df.to_csv('bigdata.csv', encoding='utf-8',index=False,columns=cols)
text = input("Please input the part number: ")
start = timeit.default_timer()
df = pd.read_csv('bigdata.csv', encoding='utf-8')
new_df = df[(df['PPF_PPNO']==text)]
print(new_df)
stop = timeit.default_timer()
print (round(stop - start,3),'s')

