# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""

import os
import glob
import shutil
import win32com.client
from datetime import date, timedelta, datetime
from collections import OrderedDict
import pandas as pd
import numpy as np
import openpyxl as xl


mypath = 'C:\\jluo\\data\\New\\report\\claim\\'
os.chdir(mypath)
FileList = glob.glob('*.xls')
# print(FileList)

file2 = 'C:\\Users\\jluo27\\Desktop\\claim.csv'

dates = ["2018-06-01", str(date.today().replace(day=1) - timedelta(days=1))]
start, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_month = list(OrderedDict(((start + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - start).days)).keys())
# print(list_month)

report = pd.DataFrame() 
# writer = pd.ExcelWriter(file2, engine='xlsxwriter')
ws = pd.DataFrame()
for x in range(len(FileList)):
    df = pd.read_excel(mypath + '\\' + FileList[x], sheet_name = 'SHEET')
    df.columns = df.columns.str.lower()
    s = (FileList[x].split('-'))[0]
    df['workstream'] = FileList[x].replace('.xls', '').replace(s + '-', '')
    ndf = df[df['load month'].isin(list_month)]
    ws = ndf[['workstream','model year','claim key','country repaired','load month','total cost gross','vehicle line global','vehicle line global desc']]
    print(FileList[x])
    report = report.append(ws)

    
report.to_csv(file2,index=False, encoding='utf-8')