# -*- coding: utf-8 -*-
"""
must use 64bit to open ODBC  'Ctrl + Shift + F1'
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

# list_folder =['Monthly','WCC']
list_folder =['Monthly']

# slection ='Monthly'
# slection ='WCC'
# cw = 'CLAIMLIS'
# cw = 'TISREP'

# cnxn = pyodbc.connect(driver='{sql server native client 11.0}', server='(localdb)\MyInstance', database='CLAIM',trusted_connection='yes')
# crsr = cnxn.cursor()


mypath = 'C:/jluo/Export/global/'
# dftest = pd.read_csv('C:/jluo/Export/ALL/CLAIMLIStest.CSV', encoding='utf-8', warn_bad_lines=False, error_bad_lines=False)
# col_name = dftest.columns.values.tolist()
col_name = ['Model Year', 'Body/Cab Desc', 'Body/Cab Type [BS/CA]', 'Claim Key', 'Condition Code', 'Condition Code Desc', 
            'Country Repaired', 'Country Sold', 'Customer Concern Code', 'Customer Concern Code Desc', 
            'Document Number', 'Engine [EN]', 'Engine Desc', 'Labor Cost', 'Labor Hours', 'Load Month', 
            'Material Cost', 'Mileage', 'Misc. Amt (total)', 'Part Num Base (Causal)', 'Production Month', 
            'Production Date', 'QB Global Sub Groups', 'Repair Date', 'Repair Dealer Code', 'Repair Dealer Name', 
            'Repair Dealer Phone Num', 'Sell Dealer Code', 'TIS', 'Total Cost Gross', 'Transmission [TR]', 
            'Transmission Desc', 'Vehicle Line Global', 'Vehicle Line Global Desc', 'VIN', 'WCC', 'WCC Desc', 
            'Warranty Start Date', 'Part Num Suffix (Causal)', 'Part Num Full OB (Causal)', 'Part Num Prefix (Causal)', 
            'Country Built', 'FCC Authorization', 'Tech Comments (English)', 'Customer Comments', 'Technician Comments']

for i in range(len(list_folder)):
    slection = list_folder[i]
    # sql = 'select * from %s' % slection + 'CLAIMLIST'
    # df = pd.read_sql(sql, cnxn)
    # # df = pd.read_csv(mypath + slection + 'CLAIMLIST.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python',skiprows=1)
    # df.columns = col_name
    # db = pd.read_csv(mypath + 'Monthly/Panda_BPNO.CSV', warn_bad_lines=False, error_bad_lines=False)
    # ppno = df['Part Num Full OB (Causal)']
    # lh = df['Labor Hours']
    # ddf = pd.DataFrame()   
    # ddf['PPF_PPNO'] = ppno.map(lambda x: re.sub(r'-', '',str(x)).rstrip('*'))
    # ddf['lhfloor'] = np.int_(np.floor(lh))
    # ddf['lhceil'] = np.int_(np.ceil(lh))
    # mdf = pd.merge(ddf, db[['PPF_PPNO', 'Panda_DESC']],how='left', on=['PPF_PPNO'])

    # # # df['Labor_Hours2'] = int(np.floor(lh)) 
    # # # df['Labor_Hours2'] = np.int_(np.floor(lh)) + '~' + np.int_(np.ceil(lh))
    # # # df['Labor_Hours2'] = np.int_((np.floor(lh))).astype(str) + '~' + np.int_((np.ceil(lh))).astype(str)
    # df['Labor_Hours2'] = ddf[['lhfloor','lhceil']].apply(lambda x : '{}-{}'.format(x[0],x[1]), axis=1)
    # df['Panda_DESC'] = mdf['Panda_DESC']

    # newcolumns = ['Model Year','VIN','Country Built','Country Sold','Country Repaired','Body/Cab Desc','Body/Cab Type [BS/CA]',
    # 'Condition Code','Condition Code Desc','Customer Concern Code','Customer Concern Code Desc','Document Number','Labor Hours','Labor_Hours2',
    # 'Labor Cost','Material Cost','Misc. Amt (total)','Total Cost Gross','Load Month','Production Month','Production Date','Repair Date','Warranty Start Date',
    # 'Tech Comments (English)','Customer Comments','Technician Comments','Repair Dealer Code','Repair Dealer Name',
    # 'Repair Dealer Phone Num','Sell Dealer Code','Mileage','TIS','Transmission [TR]','Transmission Desc','Claim Key','Vehicle Line Global',
    # 'Vehicle Line Global Desc','Engine [EN]','Engine Desc','WCC','WCC Desc','QB Global Sub Groups','Part Num Full OB (Causal)',
    # 'Part Num Prefix (Causal)','Part Num Base (Causal)','Part Num Suffix (Causal)','FCC Authorization','Panda_DESC']	
    # # df.to_csv(mypath + 'Monthly/'+ slection  + 'CLAIMLIS.CSV', encoding='utf-8',index=False,columns=newcolumns)
    # stop = timeit.default_timer()
    # print (slection,'claims',round(stop - start,3),'s')

    dftis = pd.read_csv(mypath + '/TISREP.CSV', encoding='utf-8', warn_bad_lines=False, error_bad_lines=False)
    dftis = dftis.drop(['MATRIX_NO','R1000','CPU','CPR','LOGIC'],axis=1)
    if slection =='WCC':
        dftis = dftis[(dftis['WCC'] != 'BLANK') & (dftis['WCC'] != 'TOTAL')]
    else:
        dftis['Vehicle Line Global'] = dftis['Vehicle Line Global'].str.split(' - ').str[0]
        dftis = dftis[(dftis['PART NUM BASE (CAUSL)'] != 'BLANK') & (dftis['PART NUM BASE (CAUSL)'] != 'TOTAL')]
    dftis = dftis.dropna(axis=0,how='any')
    dftis = dftis[dftis['MODEL YEAR'] >2010]
    dftis.to_csv('C:/jluo/Export/global/Global'+ slection + 'TISREP.CSV', encoding='utf-8',index=False)
    stop = timeit.default_timer()
    print (slection,'tis',round(stop - start,3),'s')
	

