# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
需要打开excel文件更新一下
"""
import os
import re
from pathlib import Path
from pptx.util import Inches
from pptx import Presentation
import win32com.client
from pptx.util import Pt
Excel=win32com.client.Dispatch("Excel.Application")

myFolder = 'C:\\jluo\\data\\report\\BPR'
destdir = Path(myFolder)
files = [p for p in destdir.iterdir() if p.is_file()]

range_list =['B7:E19','F7:N19','F24:N32']
# # # left, top, width, height
left_list =[0.74,6.84,6.84]
top_list =[1.59,1.59,3.95]
prs = Presentation('C:\\jluo\\tool\\AP BPR PPT.pptx')


for f in files:
    try:
        # print(files.index(f),f)
        wb=Excel.Workbooks.Open(Filename=f,UpdateLinks=False)
        slide = prs.slides[files.index(f)]
        textbox = slide.shapes.add_textbox(Inches(0.5), Inches(0.1), Inches(9), Inches(1))  # left，top为相对位置，width，height为文本框大小
        textbox.text = [os.path.basename(f)][0]
        # textbox.textframe.paragraphs[0].runs[0].size = Pt(30)
        for i in range(len(range_list)):
            wb.Worksheets('Chart').Range(range_list[i]).CopyPicture()
            pit = Excel.ActiveSheet.ChartObjects().Add(0,0,409,144)
            pit.Chart.Paste()
            pit.Chart.Export('C:\\Users\\jluo27\\Pictures\\kk' + str(i) +'.png')   
            slide.shapes.add_picture('C:\\Users\\jluo27\\Pictures\\kk' + str(i) +'.png', Inches(left_list[i]) , Inches(top_list[i]))    
        wb.Close(SaveChanges=False)
        print(files.index(f)+1,'----->', [os.path.basename(f)][0])
    except:
        # del Excel
        continue

prs.save('C:\\Users\\jluo27\\Desktop\\FNG Door Check Arm Assy.pptx')
del Excel
