# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime

curr = date.today().replace(day=1) - timedelta(days=1)
prev = date.today().replace(day=1) - timedelta(days=32)
CM = curr.strftime("%Y-%m")
LM = prev.strftime("%Y-%m")

	 
df = pd.read_csv('C:/jluo/Export/PYDATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
dp = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['WCC_Code'] = df['WCC'].str.split(' - ').str[0]
df['VLPart'] = df[['VL','PART NUM BASE (CAUSL)']].apply(lambda x : '{}-{}'.format(x[0],x[1]), axis=1)

# df = df[(df['PART NUM BASE (CAUSL)']=='6342528')]
# df = df[df['PART NUM BASE (CAUSL)'].str.contains('782')]
# df = df[(df['PART NUM BASE (CAUSL)']=='2141022') | (df['PART NUM BASE (CAUSL)']=='2141023') ]
df = df[df['QB Global Sub Group'].str.contains('GQB5')]
# df = df[df['VFG'].str.contains('V31')]
# df = df[df['Vehicle Line Global'].str.contains('RANGER')]
# df = df[df['VL']=='ZB']
# df = df[df['WCC_Code']=='7A01']
# df = df[df['Country Repaired'].str.contains('AUS')]
# df = df[(df['PART NUM BASE (CAUSL)']=='3F830') & (df['VL']=='K3')]
df = df[(df['Load Month']==CM) | (df['Load Month']==LM)]

# print(df.REPAIRS.sum(),df.COSTS.sum()/12)
ttl_df = pd.pivot_table(df,index=["VLPart"],values=["COSTS"],
               columns=["Load Month"],aggfunc=[np.sum]).reset_index()
ttl_df = ttl_df.fillna(0)
ttl_df.columns = ['VLPart',LM,CM]
ttl_df['inc'] = ttl_df[CM]-ttl_df[LM]
ttl_df = ttl_df.sort_values(by=['inc'], ascending=0).head(30)
# print(ttl_df)

x = ttl_df['VLPart']
y1 = ttl_df[LM]  #ttl_df['VW']
y2 = ttl_df[CM]


index = np.arange(len(x)) 
bar_width = 0.3 
alpha_value = 1
# fig = plt.figure(figsize=(12,8))
fig,ax = plt.subplots(figsize=(12,6))  
# plt.grid(which='major',axis='y')

ax1= plt.bar(index , y1, bar_width, color='b',label=LM)
ax2= plt.bar(index+bar_width, y2, bar_width, color='r',label=CM)

plt.xticks(index, x, rotation='vertical',fontsize=8)    
plt.legend(ncol=3)
plt.tight_layout()
fig.savefig('C:/Users/jluo27/Desktop/bi.png')  
ttl_df.to_csv('C:/Users/jluo27/Desktop/bi.CSV', encoding='utf-8',index=False)
plt.show()


