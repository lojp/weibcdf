# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
from matplotlib.gridspec import GridSpec
from collections import OrderedDict

dates = ["2019-04-01", str(date.today().replace(day=1) - timedelta(days=1))]
start, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_month = list(OrderedDict(((start + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - start).days)).keys())

bpno_df = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
bpno_df.columns = ['PART NUM BASE (CAUSL)', 'Description']
	 
df = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['WCC_Code'] = df['WCC'].str.split(' - ').str[0]


df = df[df['Load Month'].isin(list_month)]
# df = df[df['Country Repaired'].str.contains('CHN|TWN')]
# df = df[(df['PART NUM BASE (CAUSL)']=='18124')]
df = df[df['PART NUM BASE (CAUSL)'].str.contains('19703')]
# df = df[(df['PART NUM BASE (CAUSL)']=='2141022') | (df['PART NUM BASE (CAUSL)']=='2141023') ]
# df = df[df['QB Global Sub Group'].str.contains('GQB4')]
# df = df[df['VFG'].str.contains('V31')]
df = df[df['Vehicle Line Global'].str.contains('MUSTANG')]
# df = df[df['VL']=='HG']
# df = df[df['WCC_Code']=='7A01']
# df = df[df['Country Repaired'].str.contains('AUS')]
# df = df[(df['PART NUM BASE (CAUSL)']=='3F830') & (df['VL']=='K3')]
# df = df[df['Load Month'].str.contains('2017')]

# # 输出数据到excel
vl_df = pd.pivot_table(df,index=['PART NUM BASE (CAUSL)','Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
new_df = pd.merge(vl_df, bpno_df ,how='left', on=['PART NUM BASE (CAUSL)'])
writer = pd.ExcelWriter('C:/Users/jluo27/Desktop/GQB4.xlsx', engine='xlsxwriter')
new_df.to_excel(writer, sheet_name='rawdata',index=False, encoding='utf-8')
writer.save()


ttl_df = pd.pivot_table(df,index=['Load Month'], values=['COSTS','REPAIRS'],aggfunc='sum').reset_index()
ttl_df['CPR'] =ttl_df.COSTS/ttl_df.REPAIRS
c_df = pd.pivot_table(df,index=['Country Repaired'], values=['COSTS'],aggfunc='sum').reset_index()
c_df['Percent'] = c_df.iloc[:, 1:].apply(lambda x: x / x.sum())
# # c_df['Percent'] = c_df['Percent'].apply(lambda x: "{0:.2f}%".format(x*100))
# # c_df['percentage'] = (c_df / c_df.groupby(['Country Repaired']).transform(sum))['COSTS']  # each group
c_df = c_df.sort_values(by=['COSTS'], ascending=0)
c_df['cty'] = np.where(c_df['Percent']>0.02, c_df['Country Repaired'].str.split(' - ').str[1], '')


v_df = pd.pivot_table(df,index=['Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
v_df['Percent'] = v_df.iloc[:, 1:].apply(lambda x: x / x.sum())
v_df = v_df.sort_values(by=['COSTS'], ascending=0)
v_df['vl'] = np.where(v_df['Percent']>0.02, v_df['Vehicle Line Global'].str.split(' - ').str[1], '')

my_xticks = ttl_df['Load Month']
y1 = ttl_df['COSTS']/1000
y2 = ttl_df['CPR']
x = np.arange(len(my_xticks))


# # plt.style.use('ggplot')
# fig = plt.figure(figsize=(10,6))
# plt.xticks(x, my_xticks,rotation=90, fontsize=7)
# plt.plot(x,y,'r-',label='Costs')
# plt.plot(x,y2,'b--',label='CPR')
# plt.ylim(ymin=0)
# # plt.ylabel("Cumulative density")
# # plt.xlabel("TIS")
# # plt.title('lod', fontsize=16)		 
# plt.legend()
# plt.show()



fig = plt.figure(figsize=(11,7))

# ax1 = plt.subplot2grid((2, 3), (0, 0))
ax1 = plt.subplot2grid((2, 3), (0, 0), colspan=2)
ax3 = plt.subplot2grid((2, 3), (1, 0), colspan=1, rowspan=1)
ax4 = plt.subplot2grid((2, 3), (1, 2), rowspan=1)


# ax1 = fig.add_subplot(211)
ax1.set_xlabel('Load Month')
ax1.set_ylabel('warranty spends($K)')
lns1 = ax1.plot(x, y1, 'ko-',label = 'Warranty spends')
ax1.set_ylim(0,1.2*ttl_df.COSTS.max()/1000)
ax1.set_xticks(x)
ax1.set_xticklabels(my_xticks, rotation=90, fontsize=7)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
ax2.set_ylabel('CPR')  # we already handled the x-label with ax1
lns2 =ax2.plot(x, y2, 'b*--',label = 'CPR')
ax2.set_ylim(0,1.1*ttl_df.CPR.max())

lns = lns1+lns2
labs = [l.get_label() for l in lns]
ax1.legend(lns, labs, loc=0)


def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data

cty = c_df['COSTS']
c_labels = c_df['cty']
# ax3 = fig.add_subplot(234)
ax3.pie(cty, labels=c_labels, autopct=autopct_more_than_1)
# # # ax3.pie(cty, labels=c_labels, autopct='%.0f%%')
# patches, texts, autotexts = ax3.pie(cty, labels=c_labels, autopct=autopct_more_than_1)
# for t in texts:
    # t.set_size('smaller')
# for t in autotexts:
    # t.set_size('x-small')

vl = v_df['COSTS']
v_labels = v_df['vl']
# ax4 = fig.add_subplot(236)
ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_1)


fig.set_tight_layout(True)
fig.savefig('C:/Users/jluo27/Desktop/foo.png')
plt.show()

