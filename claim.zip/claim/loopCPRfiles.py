# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""

import os
import glob
import shutil
import win32com.client
import pandas as pd
import numpy as np
import openpyxl as xl


mypath = 'C:\\jluo\\data\\New\\cpr\\'
os.chdir(mypath)
FileList = glob.glob('*.xls')
# print(FileList)

file2 = 'C:\\Users\\jluo27\\Desktop\\workbook2.xlsx'

report = pd.DataFrame() 
writer = pd.ExcelWriter(file2, engine='xlsxwriter')
ws = pd.DataFrame()
for x in range(len(FileList)):
    try:
        ws = pd.read_excel(mypath + '\\' + FileList[x], header = None, sheet_name = 'cpr_chart',  skiprows=40, usecols="O:AX")
        s = (FileList[x].split('-'))[0]
        ws['workstream'] = FileList[x].replace('.xls', '').replace(s + '-', '')
        print(FileList[x])
        report = report.append(ws.head(2))
    except:
        continue
    
report.to_excel(writer, 'sheet1' ,index=False, encoding='utf-8')
writer.save()