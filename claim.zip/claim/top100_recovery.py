# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
from datetime import date, timedelta, datetime
from collections import OrderedDict
import os
import win32com.client
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import shutil
begin = timeit.default_timer()

mydir = 'C:/jluo/data/New/top/'
if os.path.exists(mydir):
    shutil.rmtree(mydir)
os.makedirs(mydir)

list_lincoln_vl = ['B4', 'LM', 'LG', 'MX', 'ZI', 'ZK']
dates = ["2017-01-01", str(date.today().replace(day=1) - timedelta(days=1))]
start, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_month = list(OrderedDict(((start + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - start).days)).keys())

prev = date.today().replace(day=1) - timedelta(days=1)
LM = prev.strftime("%Y-%m")
CM = date.today().strftime("%Y-%m")

p_column= ['PART NUM BASE (CAUSL)']
v_column= ['Vehicle Line Global']
bd_column= ['Vehicle Line Global', 'VL_PART']
p_column.extend(list_month)
v_column.extend(list_month)
bd_column.extend(list_month)


bpno_df = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
bpno_df.columns = ['PART NUM BASE (CAUSL)', 'Description']
# # ['Base Part Number', 'Base Part Description']
# # print(bpno_df.columns)
   
df = pd.read_csv('C:/jluo/Export/Monthly/PYTOP.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
df = df[df['Load Month'].isin(list_month)]
df['QB'] = df['QB Global Sub Group'].str[:4]
df = df[df['Country Repaired'].str.contains('CHN|TWN')]
# df = df[df['Vehicle Line Global'].str.contains('Nautilus')]
df['VL_PART'] = df[['Vehicle Line Global','PART NUM BASE (CAUSL)']].apply(lambda x : '{}_{}'.format(x[0],x[1]), axis=1)
qb_df = pd.pivot_table(df,index=['QB Global Sub Group'], values=['COSTS'],aggfunc='sum').reset_index()   ###QB Global Sub Group
subqb = list(qb_df['QB Global Sub Group'].str.split(' - ').str[0].replace('\*', '', regex=True))     ###QB Global Sub Group
# df1 = df[df['Load Month']==LM]
# print(subqb)



# for i in range(len(subqb)): 
    # try:
        # ndf = df[df['QB Global Sub Group'].str.contains(subqb[i])]
        # # ndf = df[df['Vehicle Line Global'].str.contains(subqb[i])]
        # lm_df = ndf[ndf['Load Month']==LM]


        # breakdown_df = pd.pivot_table(ndf,index=['PART NUM BASE (CAUSL)','VL_PART'], values=['COSTS'],aggfunc='sum').reset_index()
        # breakdown_df['group_rank'] = breakdown_df.groupby('PART NUM BASE (CAUSL)')['COSTS'].rank(ascending=0,method='dense')
        # bd_df = pd.pivot_table(df,index=['Vehicle Line Global', 'VL_PART'], columns = ['Load Month'], values=['COSTS'],aggfunc='sum').reset_index()
        # # print(bd_df.head(5))
        
        # bd_df.columns = bd_column
        # bd_new_df = pd.merge(breakdown_df, bd_df,how='left', on=['VL_PART'])
        # bd_new_df = bd_new_df.drop(['COSTS'],axis=1)

        
        
        # p_ttl_df = pd.pivot_table(ndf,index=['PART NUM BASE (CAUSL)'], columns = ['Load Month'], values=['COSTS'],aggfunc='sum').reset_index()
        # # print(p_ttl_df.head(3))
        # p_ttl_df.columns = p_column
        # p_sort_lm_df = pd.pivot_table(lm_df,index=['PART NUM BASE (CAUSL)'], values=['COSTS'],aggfunc='sum').reset_index()
        # p_sort_lm_df = p_sort_lm_df.sort_values(by=['COSTS'], ascending=0)
        # p_sort_lm_df = p_sort_lm_df.drop(['COSTS'],axis=1)
        # p_new_df = pd.merge(p_sort_lm_df, p_ttl_df ,how='left', on=['PART NUM BASE (CAUSL)'])

        # bpno_new_df = pd.merge(p_sort_lm_df, bpno_df ,how='left', on=['PART NUM BASE (CAUSL)'])

        # bd_df_1 = pd.merge(p_sort_lm_df, bd_new_df[bd_new_df['group_rank']==1],how='left', on=['PART NUM BASE (CAUSL)'])
        # bd_df_2 = pd.merge(p_sort_lm_df, bd_new_df[bd_new_df['group_rank']==2],how='left', on=['PART NUM BASE (CAUSL)'])
        # bd_df_3 = pd.merge(p_sort_lm_df, bd_new_df[bd_new_df['group_rank']==3],how='left', on=['PART NUM BASE (CAUSL)'])
        # bd_df_4 = pd.merge(p_sort_lm_df, bd_new_df[bd_new_df['group_rank']==4],how='left', on=['PART NUM BASE (CAUSL)'])


        # v_ttl_df = pd.pivot_table(ndf,index=['Vehicle Line Global'], columns = ['Load Month'], values=['COSTS'],aggfunc='sum').reset_index()
        # v_ttl_df.columns = v_column
        # v_sort_lm_df = pd.pivot_table(lm_df,index=['Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
        # v_sort_lm_df = v_sort_lm_df.sort_values(by=['COSTS'], ascending=0)
        # v_sort_lm_df = v_sort_lm_df.drop(['COSTS'],axis=1)
        # v_new_df = pd.merge(v_sort_lm_df, v_ttl_df ,how='left', on=['Vehicle Line Global'])


        # writer = pd.ExcelWriter('C:/jluo/tool/top100.xls', engine='xlsxwriter')
        # p_new_df.head(100).to_excel(writer, sheet_name='part',index=False, encoding='utf-8')	
        # v_new_df.head(100).to_excel(writer, sheet_name='vl',index=False, encoding='utf-8')
        # bpno_new_df.head(100).to_excel(writer, sheet_name='desc',index=False, encoding='utf-8')
        # bd_df_1.drop(['PART NUM BASE (CAUSL)','VL_PART','group_rank'],axis=1).head(100).to_excel(writer, sheet_name='bd1',index=False, encoding='utf-8')
        # bd_df_2.drop(['PART NUM BASE (CAUSL)','VL_PART','group_rank'],axis=1).head(100).to_excel(writer, sheet_name='bd2',index=False, encoding='utf-8')
        # bd_df_3.drop(['PART NUM BASE (CAUSL)','VL_PART','group_rank'],axis=1).head(100).to_excel(writer, sheet_name='bd3',index=False, encoding='utf-8')
        # bd_df_4.drop(['PART NUM BASE (CAUSL)','VL_PART','group_rank'],axis=1).head(100).to_excel(writer, sheet_name='bd4',index=False, encoding='utf-8')	
        # writer.save()
        
        # xl=win32com.client.Dispatch("Excel.Application")
        # # xl.Application.Visible = True
        # wb = xl.Workbooks.Open(Filename="C:/jluo/tool/Top100_model_py.xls")
        # xl.Application.Run("Module1.A_generate_rpt")
        # xl.Application.ActiveWorkbook.SaveAs('C:\\jluo\\data\\New\\top\\CN_Top100_' + subqb[i] + '.xls') 
        # wb.Close(SaveChanges=True)
        # xl.Application.Quit() # Comment this out if your excel script closes
        # del xl
    # except:
        # continue
    # stop = timeit.default_timer()
    # print (subqb[i],round(stop - begin,3),'s')
    
    
