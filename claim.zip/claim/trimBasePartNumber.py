# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""


import numpy as np
import pandas as pd
import re


all_df = pd.read_csv('C:/jluo/Export/JLUO27.csv', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')

all_df['Base Part Number'] = all_df['Base Part Number'].str.replace('[^a-zA-Z0-9]','')
all_df.to_csv('C:/jluo/Export/Monthly/JLUO27.csv', index=None)
# print(all_df.head(5))