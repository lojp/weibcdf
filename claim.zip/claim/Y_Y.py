# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import pandas as pd
import os
import numpy as np

dir_name = 'C:/Users/jluo27/Downloads/'
os.chdir(dir_name)

# filelist =['CLAIMLIS','TISREP','CPRRPM']  #,'CLAIMLS1','TISREP1','CLAIMLS2','TIEREP2']   
filelist =['CLAIMLIS','TISREP','CLAIMS','TISS']

for j in filelist:      
    if os.path.exists(j + '.CSV'):
        os.remove(j + '.CSV')
    else:
        pass


with open('CPRRPM.CSV', newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    for  i, row in enumerate(reader):
        if i == 1:
            list = [j.split(',',0) for j in row]
            df = pd.DataFrame(list)
            df.to_csv('cri.txt', header=None, index=None)

os.remove('CPRRPM.CSV')
os.startfile('cri.txt')
