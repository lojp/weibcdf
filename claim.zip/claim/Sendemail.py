# -*- coding: utf-8 -*-
"""
Created on Fri Mar 08 09:37:17 2018
@author: jluo27
refer to: 
1, https://www.zhidaow.com/post/python-envelopes
2, http://blog.csdn.net/qq_26925867/article/details/72843389
"""
import pandas as pd          
import win32com.client as win32  
from datetime import date, timedelta, datetime

prev = date.today().replace(day=1) - timedelta(days=1)
outlook = win32.Dispatch('outlook.application')  
df = pd.read_excel('C:/jluo/tool/VFGEmailList.xlsx', sheet_name='Sheet1')
df = df[df['SubQB']=='GQB5A']

for i in range(len(df)):
    subqb = df.iloc[i,0]
    receivers = (df.iloc[i,1]).split(',') 
    for j in range(len(receivers)):
        mail = outlook.CreateItem(0)  
        mail.To = receivers[j]
        mail.Subject ='***Top100 Report for ' + subqb + '***'
        mail.Body = '***Top100 report has been updated with the ' + prev.strftime(r"%B %Y") + ' Cutoff data***' + '\n\n' + 'Best Regards,' + '\n' + 'Rogers'
        mail.Attachments.Add('C:/jluo/data/New/top/Top100_' + subqb +'.xls')  
        mail.Send()  