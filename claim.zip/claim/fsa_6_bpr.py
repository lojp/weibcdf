# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
# from pandas import *
import re
import os
import warnings
import timeit
import shutil
start = timeit.default_timer()
warnings.simplefilter("ignore")


mypath = 'C:/jluo/Export/'

mydir = 'C:/jluo/data/New/BPR/'

if os.path.exists(mydir):
    shutil.rmtree(mydir)
os.makedirs(mydir)
        
dfclm = pd.read_csv('C:/jluo/Export/FSA/PYCLAIM.CSV', encoding='utf-8', warn_bad_lines=False, error_bad_lines=False)
# dfclm['VL'] = dfclm['Vehicle Line Global'].str.split(' - ').str[0]
dfclm['VL'] = dfclm['Vehicle Line Global']

ndftis = pd.read_csv('C:/jluo/Export/FSA/PYTIS.CSV', encoding='utf-8', warn_bad_lines=False, error_bad_lines=False)
dftis = ndftis[(ndftis['PART NUM BASE (CAUSL)'] != 'BLANK')]
# dftis = ndftis[(ndftis['WCC'] != 'BLANK')]
# dftis['VL'] = dftis['Vehicle Line Global'].str.split(' - ').str[0]
dftis['VL'] = dftis['Vehicle Line Global']

vltis = pd.pivot_table(dftis,index=['VL','MODEL YEAR','TIS'], values=['VEHICLES'],aggfunc=np.max).reset_index()
# vlsumtis = pd.pivot_table(vltis,index=['MODEL YEAR','TIS'], values=['VEHICLES'],aggfunc=np.sum).reset_index()
# print(vltis.head(5))

dp = pd.read_excel('C:/jluo/Export/Monthly/temp.xlsx',sheet_name='Sheet1')
# dp =ndp[ndp['item'].str.contains('2C')]
# print(dp.head(5))

actdf = pd.read_csv('C:/jluo/Export/Monthly/Actionlist.CSV', encoding='utf-8',skiprows=1)
actdf.columns = ['Action','Description','Impl_Date','Implementation Status','WS Reduction Tool Category','Workstream','Workstream_Desc']
actdf = actdf[actdf['Implementation Status']=='(1G) Action Implemented']
actdf = actdf[(actdf['WS Reduction Tool Category']=='(a) ICA') | (actdf['WS Reduction Tool Category']=='(b) PCA')]

act = pd.DataFrame()

for i in range(len(dp)):
# for i in range(2):
    s = dp.iloc[i,1].split('_')[0]
    act = actdf[actdf['Workstream_Desc']==s]
    act = act.drop(['Action','Implementation Status','WS Reduction Tool Category','Workstream','Workstream_Desc'],axis=1)
    act = act.sort_values(by=['Impl_Date'], ascending=0)    
    
    try:
        mylist44 = (dp.iloc[i,2]).split(',') #part
        # mylist39 = (dp.iloc[i,2]).replace('WCC','').split(',') #wcc
        # # mylist35 = (dp.iloc[i,3]).split(',') #VL
        dtlist1 = pd.DataFrame(np.array(mylist44).reshape(-1), columns = ['Part'])
        # # dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
        # dtlist3 = pd.DataFrame(np.array(mylist39).reshape(-1), columns = ['WCC'])
		
        if dp.iloc[i,0] ==2:
	        mylist35 = (dp.iloc[i,3]).split(',')
	        dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
	        dff = dfclm[dfclm.iloc[:,9].isin(mylist44)]
	        clmlist = dff[dff.iloc[:,11].isin(mylist35)]
	        dkk = dftis[dftis.iloc[:,10].isin(mylist44)]
	        dk = dkk[dkk.iloc[:,13].isin(mylist35)]
	        # dkvl = vltis[vltis.iloc[:,0].isin(mylist35)]
	        # dtlist3 = dtlist3[0:0]
	        # print('2')
	        
        elif dp.iloc[i,0] ==1:
	        mylist35 = (dp.iloc[i,3]).split(',')
	        dtlist2 = pd.DataFrame(np.array(mylist35).reshape(-1), columns = ['Vehicle Line Global'])
	        dff = dfclm[dfclm.iloc[:,9].isin(mylist44)]
	        clmlist = dff[dff.iloc[:,11].isin(mylist35)]
	        dkk = dftis[dftis.iloc[:,10].isin(mylist44)]
	        dk = dkk[dkk.iloc[:,11].isin(mylist35)]
	        # dkvl = vltis[vltis.iloc[:,0].isin(mylist35)]            
	        # dtlist3 = dtlist3[0:0]
	        # print('1')
	        
        elif dp.iloc[i,0] ==0:	
	        clmlist = dfclm[dfclm.iloc[:,9].isin(mylist44)]
	        dk = dftis[dftis.iloc[:,10].isin(mylist44)]  
	        # dkvl = vltis
	        dtlist2 = pd.DataFrame({'Vehicle Line Global' : []})
	        # dtlist3 = pd.DataFrame({'WCC' : []})
	        # print(dkvl)	        
        else:
	        pass
        
        
        tis1 = pd.pivot_table(dk,index=['VL','MODEL YEAR','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
        tis2 = pd.pivot_table(tis1,index=['MODEL YEAR','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
        tis2['VL'] = 'TOTAL'
        # tisvls = pd.pivot_table(dkvl,index=['MODEL YEAR','TIS'], values=['VEHICLES'],aggfunc=np.sum).reset_index()
        # tis2['VEHICLES'] = tisvls['VEHICLES']

        clm = pd.pivot_table(clmlist,index=['VL','Load Month', 'Production Month'], values=['REPAIRS','COSTS'],aggfunc='sum').reset_index()
	
        tis = tis1.append(tis2, ignore_index=True)
        # tis['PROD_MONTH'] = pd.to_datetime(tis['PROD_MONTH'])  #时间修改
        print(i+1,'----->',dp.iloc[i,1])
        writer = pd.ExcelWriter(mydir + dp.iloc[i,1] + '.xls', engine='xlsxwriter')
        
        dt1 = pd.DataFrame(clm)	
        dt1.to_excel(writer, sheet_name='claim',index=False, encoding='utf-8')
        # report = report.append(dt1)
		
		
        dt2 = pd.DataFrame(tis)
        cols = ['VL','MODEL YEAR','TIS','REPAIRS','COSTS','VEHICLES']
        dt2.to_excel(writer, sheet_name='tis',index=False,columns=cols, encoding='utf-8')		
        
        act.to_excel(writer, sheet_name='action',index=False, encoding='utf-8')	
        dtlist1.to_excel(writer, sheet_name='LIST_PARTS',index=False, encoding='utf-8')	
        dtlist2.to_excel(writer, sheet_name='LIST_VL',index=False, encoding='utf-8')
        dtlist3.to_excel(writer, sheet_name='LIST_OPTION',index=False, encoding='utf-8')        
        writer.save()

    except:
        # print('4')
        continue
    
# report.to_csv('C:/jluo/Export/checklist.CSV', encoding='utf-8',index=False)
stop = timeit.default_timer()
print (round(stop - start,3),'S',round((stop - start)/(len(dp)+1),3),'S')