# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

wl = '*LESS SPARE WL'   
#*LESS SPARE WL,*SPARE WL


dftis = pd.read_csv('C:/jluo/Export/TISREP.CSV', encoding='utf-8', warn_bad_lines=False, error_bad_lines=False)
dftis = dftis.drop(['MATRIX_NO','R1000','CPU','CPR','LOGIC'],axis=1)
dftis = dftis.dropna(axis=0,how='any')
dftis = dftis[(dftis['Region Built'] != 'BLANK') & (dftis['Region Built'] != 'TOTAL')]
dftis = dftis[dftis['Region Sold'] =='AP - ASIA PACIFIC']  
dftis = dftis[dftis['WERS Full Code'] ==wl]  
df = dftis[dftis['MODEL YEAR'] >2010]


tis1 = pd.pivot_table(df,index=['Vehicle Line Global','WERS Full Code','PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
tis2 = pd.pivot_table(tis1,index=['PROD_MONTH','WERS Full Code','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
tis2['Vehicle Line Global'] = 'AP'


tis = tis1.append(tis2, ignore_index=True)
tis['type'] = 'AP'
tis.to_csv('C:/jluo/Export/ap_less_TIS.CSV', encoding='utf-8',index=False)

stop = timeit.default_timer()
print ('tis',round(stop - start,3),'s')
	

