# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
import warnings
import timeit
import os
import sys
import shutil
import win32com.client
start = timeit.default_timer()
warnings.simplefilter("ignore")

# mydir= raw_input("Enter directory name : ")
mydir = 'C:/jluo/SpikeRecovery/data/'
excelfile = ['Claimlist','TIS']

spikename='FSA 01 - MY16-17 MKC MKX Headlamp WCC_202011'

if os.path.exists(mydir):
    shutil.rmtree(mydir)
os.makedirs(mydir)
# os.makedirs(mydir, exist_ok=True)

col_name = ['Model Year', 'VIN', 'Claim Key', 'Assembly Plant Desc','Vehicle Line Global',
       'Vehicle Line Global Desc', 'Country Built', 'Country Sold',
       'Country Repaired', 'Region Sold', 
       'Condition Code Desc', 'Customer Concern Code',
       'Customer Concern Code Desc', 'TIS', 'Mileage', 'Load Month',
       'Production Month', 'Production Date', 'Warranty Start Date',
       'Repair Date', 'Sell Dealer Code', 'Repair Dealer Code',
       'Repair Dealer Name', 'Repair Dealer Phone Num', 'Labor Hours',
       'Labor Cost', 'Material Cost', 'Misc. Amt (total)',
       'Part MarkUp Amount', 'Core Amount', 'Total Cost Gross',
       'Transmission [TR]', 'Transmission Desc', 'Engine Desc', 'Engine [EN]',
       'QB Global Sub Groups', 'VFG', 'WCC', 'WCC Desc',
       'Part Num Full OB (Causal)', 'Part Num Base Desc (Causal)',
       'Part Num Prefix (Causal)', 'Part Num Base (Causal)',
       'Part Num Suffix (Causal)', 'FCC Authorization',
       'Customer Comments (English)', 'Tech Comments (English)',
       'Customer Comments', 'Technician Comments']


dc = pd.read_csv('C:/Users/jluo27/Downloads/CLAIMS.CSV',keep_default_na=False,encoding='utf-8', error_bad_lines=False)
# print(dc.columns)
dt = pd.read_csv('C:/Users/jluo27/Downloads/TISS.CSV', encoding='utf-8')
dftis = dt.drop(['MATRIX_NO','R1000','CPU','CPR','LOGIC'],axis=1)

tis1 = pd.pivot_table(dftis,index=['Region Sold','PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
tb = tis1[tis1['TIS']==0]
tb1 = tb[tb['VEHICLES']>2]
tisdb = pd.merge(tis1, tb1[['Region Sold','PROD_MONTH']],how='inner', on=['Region Sold','PROD_MONTH'])

tis2 = pd.pivot_table(tis1,index=['PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
tis2['Region Sold'] = 'TOTAL'


tis = tisdb.append(tis2, ignore_index=True)
tis['PROD_MONTH'] = pd.to_datetime(tis['PROD_MONTH'])  #时间修改

writer = pd.ExcelWriter(mydir + 'spike.xls', engine='xlsxwriter')
########Claims
dt1 = pd.DataFrame(dc)	
dt1.to_excel(writer, sheet_name='claimlist',index=False, encoding='utf-8')
########TIS
dt2 = pd.DataFrame(tis)
cols = ['Region Sold','PROD_MONTH','TIS','REPAIRS','COSTS','VEHICLES']
dt2.to_excel(writer, sheet_name='TIS_REPORT',index=False,columns=cols, encoding='utf-8')		
     
writer.save()

newpath = 'C:/jluo/SpikeRecovery/Claims/Tem/'
if not os.path.exists(newpath):
    os.makedirs(newpath)

for j in range(len(excelfile)):
    xl=win32com.client.Dispatch("Excel.Application")
    # xl.Application.Visible = True
    shutil.copy('C:/jluo/SpikeRecovery/Past data/template/' + excelfile[j] + '_py.xls', 'C:/jluo/SpikeRecovery/Claims/Tem/' + excelfile[j] + '_py.xls')
    wb = xl.Workbooks.Open(Filename='C:/jluo/SpikeRecovery/Claims/Tem/' + excelfile[j] + '_py.xls')
    xl.Application.Run("Module1.A_generate_rpt")
    xl.Application.ActiveWorkbook.SaveAs('C:\\jluo\\SpikeRecovery\\'+ spikename +'_'+ excelfile[j] + '.xls') 
    wb.Close(SaveChanges=True)
    xl.Application.Quit() # Comment this out if your excel script closes
    del xl


stop = timeit.default_timer()
print (round(stop - start,3),'S')