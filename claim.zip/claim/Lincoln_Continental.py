# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
# from ggplot import *

curr = date.today().replace(day=1) - timedelta(days=1)
prev = date.today().replace(day=1) - timedelta(days=32)
CM = curr.strftime("%Y-%m")
LM = prev.strftime("%Y-%m")

	 
df = pd.read_csv('C:/jluo/Export/DATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python',skiprows=3)
dp = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
df['QB'] = df['QB Global Hardware'].str.split(' - ').str[0]
df['Type_PDI'] = np.where(df['TIS']<1, 'PDI', 'Non-PDI')
# print(df.columns.values.tolist())
# ['MATRIX_NO', 'PROD_MONTH', 'REPAIRS', 'COSTS', 'VEHICLES', 'MDL_YR_CD', 'QB Global Hardware', 'PART NUM BASE (CAUSL)', 
# 'WCC', 'Load Month', 'Warranty Start Month', 'Production Month', 'TIS', 'Repair Dealer P&A Code', 'LOGIC', 'QB', 'Type_PDI']

#######################################################
# ttl_df = pd.pivot_table(df[df['MDL_YR_CD']==2018],index=['TIS'], values=['COSTS'],aggfunc='sum').reset_index()
# ttl_df['Percent'] = ttl_df.iloc[:, 1:].apply(lambda x: x / x.sum())
# ttl_df['Cum_Percent'] = ttl_df['Percent'].cumsum()
# x = ttl_df['TIS']
# y1 = ttl_df['COSTS']  
# y2 = ttl_df['Cum_Percent'] 
# my_xticks = ttl_df['TIS']

# fig = plt.figure(figsize=(8,4))
# ax1 = fig.add_subplot(111)
# plt.suptitle('MY2018 Costs Pareto Chart by TIS', fontsize=15,fontweight='bold')
# ax1.set_xlabel('TIS')
# ax1.set_ylabel('Costs')
# lns1 = ax1.plot(x, y1, 'ro-',label = 'Costs')
# ax1.set_ylim(ymin=0)
# ax1.set_xticks(x)
# ax1.set_xticklabels(my_xticks)

# ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
# ax2.set_ylabel('Cum Percent')  # we already handled the x-label with ax1
# lns2 =ax2.plot(x, y2, 'b*--',label = 'Cum Percent')
# ax2.set_ylim(ymin=0)

# lns = lns1+lns2
# labs = [l.get_label() for l in lns]
# ax1.legend(lns, labs, loc=0)

# for a,b,c in zip(x,y2,y1):
    # ax2.text(a, b, '{:.0f}%'.format(b*100), ha='center', va= 'bottom',fontsize=7)
    # ax1.text(a, c+0.05, "{}K".format(int(c/1000)), ha='center', va= 'bottom',fontsize=7)

# # plt.tight_layout()
# fig.savefig('C:/Users/jluo27/Desktop/conti_2018.png')  
# ttl_df.to_csv('C:/Users/jluo27/Desktop/conti_tis_2018.CSV', encoding='utf-8',index=False)
# plt.show()
#######################################################



#######################################################
# ttl_df = pd.pivot_table(df[df['MDL_YR_CD']==2018],index=['QB'], values=['COSTS'],columns=["Type_PDI"],aggfunc='sum').reset_index()
# ttl_df.columns = ['QB','Non-PDI','PDI']
# x = ttl_df['QB']
# y1 = ttl_df['PDI']  #ttl_df['VW']
# y2 = ttl_df['Non-PDI']

# index = np.arange(len(x)) 
# bar_width = 0.3 
# alpha_value = 1
# fig,ax = plt.subplots(figsize=(8,4))  
# plt.suptitle('MY2018 PDI vs Non-PDI by QBs', fontsize=15,fontweight='bold')
# ax1= plt.bar(index , y1, bar_width, color='b',label='PDI')
# ax2= plt.bar(index+bar_width, y2, bar_width, color='r',label='Non-PDI')

# plt.xticks(index, x)    
# plt.legend(ncol=3)
# plt.figtext(0.2, 0.8, 'PDI: TIS <= 0' + '\n' + 'Non-PDI: TIS > 0', ha='left', va = 'bottom',size=8) 
# fig.savefig('C:/Users/jluo27/Desktop/conti_qb.png')  
# ttl_df.to_csv('C:/Users/jluo27/Desktop/conti_qb.CSV', encoding='utf-8',index=False)
# plt.show()
#######################################################


#######################################################
# ttl_df = pd.pivot_table(df[df['MDL_YR_CD']==2018],index=['PART NUM BASE (CAUSL)'], values=['COSTS'],columns=["Type_PDI"],aggfunc='sum').reset_index()
# ttl_df.columns = ['PART NUM BASE (CAUSL)','Non-PDI','PDI']
# ttl_df['inc'] = ttl_df['PDI']-ttl_df['Non-PDI']
# ttl_df = ttl_df.sort_values(by=['inc'], ascending=0).head(10)
# x = ttl_df['PART NUM BASE (CAUSL)']
# y1 = ttl_df['PDI']  #ttl_df['VW']
# y2 = ttl_df['Non-PDI']

# index = np.arange(len(x)) 
# bar_width = 0.3 
# alpha_value = 1
# fig,ax = plt.subplots(figsize=(8,4))  
# plt.suptitle('MY2018 PDI vs Non-PDI by Top Parts', fontsize=15,fontweight='bold')
# ax1= plt.bar(index , y1, bar_width, color='b',label='PDI')
# ax2= plt.bar(index+bar_width, y2, bar_width, color='r',label='Non-PDI')

# plt.xticks(index, x,fontsize=8)    
# plt.legend(ncol=3)
# fig.savefig('C:/Users/jluo27/Desktop/conti_part.png')  
# ttl_df.to_csv('C:/Users/jluo27/Desktop/conti_part.CSV', encoding='utf-8',index=False)
# plt.show()
#######################################################


#######################################################
ttl_df = pd.pivot_table(df[df['MDL_YR_CD']==2018],index=['PART NUM BASE (CAUSL)'], values=['COSTS'],aggfunc='sum').reset_index()
ttl_df.columns = ['Base Part Number','COSTS']
t_df = pd.merge(ttl_df, dp,how='left', on=['Base Part Number'])
t_df['Part'] = t_df[['Base Part Number','Base Part Description']].apply(lambda x : '{}-{}'.format(x[0],x[1]), axis=1)
# ttl_df = t_df.sort_values(by=['COSTS'], ascending=0).head(25)
# ttl_df = ttl_df.sort_values(by=['COSTS'], ascending=1)
# x = ttl_df['Part']
# y1 = ttl_df['COSTS']  #ttl_df['VW']


# index = np.arange(len(x)) 
# bar_width = 0.5 
# alpha_value = 1
# fig,ax1 = plt.subplots(figsize=(5,6))  

# for side in ['right','top','bottom']:
    # ax1.spines[side].set_visible(False)

# plt.suptitle('MY2018 Top 25 High Warranty Parts', fontsize=15,fontweight='bold')
# ax1= plt.barh(index , y1, bar_width, color='gray')
# plt.yticks(index, x,fontsize=8)   
# fig.subplots_adjust(top=0.93, bottom=0.05,left=0.48,right=0.925) 
# fig.savefig('C:/Users/jluo27/Desktop/conti_toppart.png') 

ttl_df = t_df.sort_values(by=['COSTS'], ascending=0) 
ttl_df.to_csv('C:/Users/jluo27/Desktop/conti_toppart.CSV', encoding='utf-8',index=False)
# plt.show()
#######################################################
