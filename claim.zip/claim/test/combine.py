# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")



# df1 = pd.read_csv('C:/jluo/Export/Monthly/CLAIMLIS.csv', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df2 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS2.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df3 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS3.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df4 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS4.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df5 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS5.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df6 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS6.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df7 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS7.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# df8 = pd.read_csv('C:/jluo/Export/Monthly/MonthlyclaimliS8.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
# print(df1.columns)
# df = pd.concat([df1,df2,df3,df4,df5,df6,df7,df8])

# df.to_csv('C:/jluo/Export/Monthly/MonthlyCLAIMLIS.CSV', encoding='utf-8',index=False)
# stop = timeit.default_timer()
# print (round(stop - start,3),'s')
	
    
    
# #_______________________________________________________________________
# df1 = pd.read_csv('C:/jluo/Export/PYTIS1.CSV', encoding='utf-8')
# df2 = pd.read_csv('C:/jluo/Export/PYTIS2.CSV', encoding='utf-8')
# df3 = pd.read_csv('C:/jluo/Export/PYCLAIM1.CSV', encoding='utf-8')
# df4 = pd.read_csv('C:/jluo/Export/PYCLAIM2.CSV', encoding='utf-8')
# df2['PART NUM BASE (CAUSL)'] = df2['WCC'].str.split(' - ').str[0]
# df4['PART NUM BASE (CAUSL)'] = df4['WCC'].str.split(' - ').str[0]
# df2 = df2.drop(['WCC'],axis=1)
# df4 = df4.drop(['WCC'],axis=1)

# dftis = pd.concat([df1,df2])
# dfclm = pd.concat([df3,df4])

# # # print(df1.columns)
# # # print(df3.columns)
# coltis = ['MATRIX_NO', 'PROD_MONTH', 'TIS', 'R1000', 'REPAIRS', 'VEHICLES',
       # 'COSTS', 'CPU', 'CPR', 'MODEL YEAR', 'PART NUM BASE (CAUSL)',
       # 'Vehicle Line Global', 'LOGIC']
# colclm = ['MATRIX_NO', 'PROD_MONTH', 'REPAIRS', 'COSTS', 'VEHICLES', 'MODEL YEAR',
       # 'Load Month', 'Production Month', 'Vehicle Line Global',
       # 'PART NUM BASE (CAUSL)', 'LOGIC']

# dftis.to_csv('C:/jluo/Export/Monthly/PYTIS.CSV', encoding='utf-8',index=False,columns=coltis)
# dfclm.to_csv('C:/jluo/Export/Monthly/PYCLAIM.CSV', encoding='utf-8',index=False,columns=colclm)
#__________________________________________________________________________________


#_______________________________________________________________________
# df = pd.read_csv('C:/jluo/Export/CPUDAT.CSV',encoding='utf-8')
# print(df.head(5))

df = pd.read_csv('C:/jluo/Export/CPUDAT.CSV', encoding='utf-8')
print(df.head(5))


