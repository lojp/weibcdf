# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

dmc = pd.read_csv('C:/jluo/Export/Monthly/FSACLAIMLIS.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')
dmt = pd.read_csv('C:/jluo/Export/Monthly/FSATISREP.CSV', warn_bad_lines=False, error_bad_lines=False)

dwc = pd.read_csv('C:/jluo/Export/Monthly/WCCCLAIMLIS.CSV', warn_bad_lines=False, error_bad_lines=False)
dwt = pd.read_csv('C:/jluo/Export/Monthly/WCCTISREP.CSV', warn_bad_lines=False, error_bad_lines=False)


dp = pd.read_excel('C:/jluo/Export/Monthly/FSAPartlist.xlsx', sheetname='Sheet1')
slsdt = pd.read_csv('C:/jluo/Export/Monthly/VVOLUME.CSV')
slsdf = slsdt.groupby(['Vehicle Line Global', 'Production Month','Country Sold'], as_index=False)['VEHICLES'].agg('sum')


for i in range(len(dp)):

    # mylist44 = (dp.iloc[i,2]).split(',') #part
    mylist44 = dp.iloc[i,2].split("!@#$%^&*")
    clmlist = dmc[dmc.iloc[:,44].isin(mylist44)]
    dk = dmt[dmt.iloc[:,7].isin(mylist44)]

    clsdt = pd.pivot_table(clmlist,index=['Vehicle Line Global','Production Month','Country Sold'], values=['VIN'],aggfunc='count').reset_index()
    slsdt = pd.merge(slsdf, clsdt[['Vehicle Line Global', 'Production Month','Country Sold']],how='inner', on=['Vehicle Line Global', 'Production Month','Country Sold'])

    clscount = pd.pivot_table(clmlist,index=['Vehicle Line Global','Production Month'], values=['VIN'],aggfunc='count').reset_index()
    slscount = pd.pivot_table(slsdt,index=['Vehicle Line Global','Production Month'], values=['VEHICLES'],aggfunc='sum').reset_index()
		
    tis1 = pd.pivot_table(dk,index=['Vehicle Line Global','PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
    tis2 = pd.pivot_table(tis1,index=['PROD_MONTH','TIS'], values=['REPAIRS','COSTS','VEHICLES'],aggfunc=np.sum).reset_index()
    tis2['Vehicle Line Global'] = 'TOTAL'

    vldf = pd.pivot_table(clmlist,index=['Vehicle Line Global','Vehicle Line Global Desc'], values=['Total Cost Gross'],aggfunc='sum').reset_index()
    vldf['vl'] = vldf['Vehicle Line Global'] + ' - ' + vldf['Vehicle Line Global Desc']
    # vldf = vldf.sort(['Total Cost Gross'], ascending=0)
		
    tis = tis1.append(tis2, ignore_index=True)
    tis['PROD_MONTH'] = pd.to_datetime(tis['PROD_MONTH'])  #时间修改
    writer = pd.ExcelWriter('C:/jluo/data/New/FSA/' + dp.iloc[i,1] + '.xls', engine='xlsxwriter')
    dt1 = pd.DataFrame(clmlist)	
    dt1.to_excel(writer, sheet_name='claimlist1',index=False)
		
    dt2 = pd.DataFrame(tis)
    cols = ['Vehicle Line Global','PROD_MONTH','TIS','REPAIRS','COSTS','VEHICLES']
    dt2.to_excel(writer, sheet_name='TIS_REPORT',index=False,columns=cols)		

    vldf.to_excel(writer, sheet_name='vllist',index=False, columns=['vl','Total Cost Gross'])
    clscount.to_excel(writer, sheet_name='TISRvolume',index=False)	
    slscount.to_excel(writer, sheet_name='TISVvolume',index=False)

    # dtlist1.to_excel(writer, sheet_name='LIST_PARTS',index=False)	
    # dtlist2.to_excel(writer, sheet_name='LIST_VL',index=False)
    # dtlist3.to_excel(writer, sheet_name='LIST_OPTION',index=False)
    print(i+1)
		



stop = timeit.default_timer()
print (round(stop - start,3),'S',round((stop - start)/(len(dp)+1),3),'S')