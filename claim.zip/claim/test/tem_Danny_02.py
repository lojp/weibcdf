# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
from collections import OrderedDict




def autopct_more_than_2(pct):
    return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data
    
def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 1 else ''  ###remove little data

    
df_rg = pd.read_excel('C:/Users/jluo27/Desktop/all_gqb5.xls',sheet_name='region')
df_ = pd.read_excel('C:/Users/jluo27/Desktop/all_gqb5.xls',sheet_name='')
df_ = pd.read_excel('C:/Users/jluo27/Desktop/all_gqb5.xls',sheet_name='')
df_ = pd.read_excel('C:/Users/jluo27/Desktop/all_gqb5.xls',sheet_name='')
df_ = pd.read_excel('C:/Users/jluo27/Desktop/all_gqb5.xls',sheet_name='')


fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(232)
    # plt.suptitle('AP ' + qb[i] + ' CHART', fontsize=15,fontweight='bold')
region= ttl_df['COSTS']
c_labels = ttl_df['Region']
ax1 = fig.add_subplot(232)
ax1.pie(region, labels=c_labels, autopct=autopct_more_than_2)


part= c_df['COSTS']
c_labels = c_df['PART NUM BASE (CAUSL)']
ax3 = fig.add_subplot(234)
ax3.pie(part, labels=c_labels, autopct=autopct_more_than_2)


vl = v_df['COSTS']
v_labels = v_df['vl']
ax4 = fig.add_subplot(236)
ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_2)

fig.tight_layout() 
fig.savefig('C:/Users/jluo27/Desktop/AP_' + qb[i] + '.png')
writer.save()