# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

cw = 'CLAIMLIS'

df = pd.read_csv('C:/jluo/Export/' + cw +'.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')
df['VIN'] = df['VIN'].str[-7:]

newcolumns = ['Model Year','VIN','Country Built','Country Sold','Country Repaired','Body/Cab Desc','Body/Cab Type [BS/CA]',
    'Condition Code','Customer Concern Code','Document Number','Labor Hours',
    'Load Month','Production Month','Production Date','Repair Date','Warranty Start Date',
    'Repair Dealer Code','Repair Dealer Name',
    'Repair Dealer Phone Num','Sell Dealer Code','Mileage','TIS','Transmission [TR]','Claim Key','Vehicle Line Global',
    'Engine [EN]','WCC','QB Global Sub Groups','Part Num Full OB (Causal)',
    'Part Num Prefix (Causal)','Part Num Base (Causal)','Part Num Suffix (Causal)','FCC Authorization']	
df.to_csv('C:/jluo/Export/claimlist.CSV', encoding='utf-8',index=False,columns=newcolumns)	


stop = timeit.default_timer()
print (round(stop - start,3),'s')