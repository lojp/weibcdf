#!/usr/bin/python  
# -*- coding: utf-8 -*-
import csv		
fp = open("C:/jluo/Export/UDB201701.txt",newline='',encoding='ISO-8859-1')

print(fp.readlines()[2:3])

#alllines=fp.readlines()
fp.close()
#for eachline in alllines:
#    print (eachline)