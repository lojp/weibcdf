# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import csv
import pandas as pd
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

list =['WCC','Monthly']



# for i in range(len(list)):
    # slection =list[i]
    # dftis = pd.read_csv('C:/jluo/Export/' + slection + '/TISREP.CSV', warn_bad_lines=False, error_bad_lines=False)
    # dftis = dftis.dropna(axis=0,how='any')
    # dftis.to_csv('C:/jluo/Export/' + slection + '/newTISREP.CSV',index=False)	
    # try:
        # dfclm = pd.read_csv('C:/jluo/Export/' + slection + '/CLAIMLIS.CSV', warn_bad_lines=False, error_bad_lines=False,usecols=range(0, 46))	
        # dfclm.to_csv('C:/jluo/Export/' + slection + '/newCLAIMLIS.CSV',index=False)	
    # except:
        # print('failed: check for header rows')
dfclm = pd.read_csv('C:/jluo/Export/Monthly/CLAIMLIS.CSV', warn_bad_lines=False, error_bad_lines=False,engine='python',usecols=range(0, 46))	
dfclm.to_csv('C:/jluo/Export/Monthly/newCLAIMLIS.CSV',index=False)		

stop = timeit.default_timer()
print (round(stop - start,3),'s')




