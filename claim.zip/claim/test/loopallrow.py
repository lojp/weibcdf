# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")

# rno

df = pd.read_csv('C:/Private/Analysis/python/mine/mature.csv', encoding='utf-8', header=None)
df.columns = ['header']

new_df = []

for i in range(len(df)): 
    if "rno" in df.loc[i,'header']:
        new_df.append(df.loc[i,'header'])
        new_df.append(df.loc[i+1,'header'])

ndf = pd.DataFrame({'new':new_df})
ndf.to_csv('C:/Private/Analysis/python/mine/new_mature.csv', encoding='utf-8',index=False)