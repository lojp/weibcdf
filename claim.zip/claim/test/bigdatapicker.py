import pprint, pickle
import pandas as pd
# pkl_file = open('C:/jluo/Export/Monthly/monthly.pkl', 'rb')

# data1 = pickle.load(pkl_file)
# pprint.pprint(data1)

# # data2 = pickle.load(pkl_file)
# # pprint.pprint(data2)

# pkl_file.close()
df = pd.read_pickle('C:/jluo/Export/Monthly/monthly.pkl')
# df = df[(df['Vehicle Line Global']=='NQ')]
# print(df.head(5))
print(df.head(5))