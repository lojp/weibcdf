import pickle
import csv
# import sys
# reload(sys)
# sys.setdefaultencoding("utf-8")
import pandas as pd
import pyodbc



conn_str = (
    r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};'
    r'DBQ=C:\jluo\CheckData.mdb;'
    )
cnxn = pyodbc.connect(conn_str)
# crsr = cnxn.cursor()

# tables = list(crsr.tables())
# print ('tables')
# for b in tables:
    # print (b)
sql = "select * from CLAIMLIS" 
df = pd.read_sql(sql, cnxn)

path_pickle = 'C:/jluo/Export/Monthly/monthly.pkl'  # Create an empty dictionary

with open(path_pickle,'wb') as pf:
    pickle.dump(df, pf)
cnxn.close() 
