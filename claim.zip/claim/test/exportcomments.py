#!/usr/bin/python  
# -*- coding: utf-8 -*-
import requests
import json
import re
import os
from bs4 import BeautifulSoup
import pprint
import urllib.parse as urlparse
from urllib.parse import urlencode
import urllib.request
import pandas as pd
import xlrd
from xlutils.copy import copy


# proxy = 'fmcpr003-p1.nb.ford.com:83'
# os.environ['http_proxy'] = proxy 
# os.environ['HTTP_PROXY'] = proxy
# os.environ['https_proxy'] = proxy
# os.environ['HTTPS_PROXY'] = proxy

payload = {'cdsid': 'jluo27', 'b64Pwd': 'cGFuZGExMg==','WslIP':'19.244.72.244','fastRegister':'No'}
login_url = 'https://www.wsl.ford.com/login.cgi'
home_url = 'https://www.globalquality.ford.com/aws/cgi-bin/jlu/detailclm2.pl'


pre_url='http://www.globalquality.ford.com/aws/cgi-bin/jlu/detailclm2.pl?srvr=AWSPPRDDG&modelyr='  
suf_url='&clmkey='
# my = '2017'
# key = '182883'

urlpre = 'https://web.gsdb2.ford.com/GSDBHomepageWeb/siteInformationSearchPost.do?method=httpGet&site='
data = xlrd.open_workbook('C:/Users/jluo27/Desktop/clmkey.xlsx')
wb = copy(data)
sht = data.sheets()[0]  
nrows = sht.nrows
s = requests.Session()  # 可以在多次访问中保留cookie
s.post(login_url, data=payload)  # POST帐号和密码，设置headers


new_table = pd.DataFrame(columns=range(0,2), index = [0]) # I know the size
for i in range(2)[1:]:
# for i in range(nrows)[1:]:
    my = sht.cell(i,0).value
    key = sht.cell(i,1).value
    url = pre_url + str(my) + suf_url + str(key)
    s.post(home_url)
    r = s.get(url)  # 已经是登录状态了
    dat = r.text
    soup = BeautifulSoup(dat,'html.parser')
    table = soup.find_all('table', attrs={'class':''})[1]
    rows = table.find_all('tr')
    for row in rows:
        tablecells = row.find_all('td')
        columns = re.sub(r'\s+', ' ',re.sub(r'(\<.*?\>)', '',str(tablecells)))
        print(columns)
        # for column in columns:
            # print(column)
		# suppname = str(tablecells[7])
		# sitename = str(tablecells[23])
		# sitecty = str(tablecells[55])
		# sh = wb.get_sheet(0)
		# sh.write(i,1,re.sub(r'\s+', ' ',re.sub(r'(\<.*?\>)', '',suppcode)).strip())
		# sh.write(i,2,re.sub(r'\s+', ' ',re.sub(r'(\<.*?\>)', '',suppname)).strip())
		# sh.write(i,3,re.sub(r'(\<.*?\>)', '',sitename).strip())
		# sh.write(i,4,re.sub(r'\s+', ' ',re.sub(r'(\<.*?\>)', '',sitecty)).strip())
		# wb.save('C:/Users/jluo27/Desktop/xhxh.xls')
