# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
from ggplot import *
start = timeit.default_timer()
warnings.simplefilter("ignore")
# os.remove('C:/jluo/Export/Monthly/NEWCLAIMS.CSV')


df = pd.read_csv('C:/jluo/Export/CPUDA.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')

# df = df.drop(['MATRIX_NO','R1000','CPU','CPR','LOGIC'],axis=1)

df['Vehicle Line Global'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df = df[(df['Vehicle Line Global'] != 'BLANK') & (df['Vehicle Line Global'] != 'TOTAL')]

# df = df.dropna(axis=0,how='any')

df = df[df.PROD_MONTH.isnull()]
df = df[df['MODEL YEAR'] >2016]
df1 = df[df['TIS'] == 6]
# df.to_csv('C:/jluo/Export/eesecpuvl.CSV', encoding='utf-8',index=False)	


pline = ggplot(aes(x='COSTS',y='CPU',colour = 'Vehicle Line Global',label = 'Vehicle Line Global'),data=df1)+\
geom_text(hjust=0.15, vjust=0.1,size =8)+\
geom_point()+\
ggtitle('AP EESE CPU MY 2017(@MIS=6)')

# t = theme_gray()
# t._rcParams['font.size'] = 6
# t._rcParams['xtick.labelsize'] = 10 # xaxis tick label size
# t._rcParams['ytick.labelsize'] = 10 # yaxis tick label size
# t._rcParams['axes.labelsize'] = 10


# pline = ggplot(aes(x='TIS',y='CPU',colour = 'Vehicle Line Global',label = 'Vehicle Line Global'),data=df)+\
# geom_line()+\
# ggtitle('AP EESE CPU MY 2017')

stop = timeit.default_timer()
print (round(stop - start,3),'s')
print(pline)