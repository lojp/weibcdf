# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
from collections import OrderedDict

dates = ["2014-01-01", str(date.today().replace(day=1) - timedelta(days=1))]
start, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_month = list(OrderedDict(((start + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - start).days)).keys())

# print(list_month)
# qb = ['GQB1', 'GQB2', 'GQB3', 'GQB4', 'GQB5', 'GQB6', 'GQB7']
qb = ['GQB5']
	 
df = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['WCC_Code'] = df['WCC'].str.split(' - ').str[0]
df['QB'] = df['QB Global Sub Group'].str[:4]
df = df[df['Load Month'].isin(list_month) & df['QB Global Sub Group'].str.contains('GQB5')]

print(list_month)

def autopct_more_than_2(pct):
    return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data
    
def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 1 else ''  ###remove little data

    
    
bpno_df = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
bpno_df.columns = ['PART NUM BASE (CAUSL)', 'Description']

vl_df = pd.read_excel('C:/Users/jluo27/Desktop/vl.xls',sheet_name='all')
writer = pd.ExcelWriter('C:/Users/jluo27/Desktop/all_QB.xls', engine='xlsxwriter')  

new_rg_df = pd.merge(df, vl_df ,how='left', on=['Vehicle Line Global'])
new_rg_df['Region'] = new_rg_df['Region Built'].str[:2]

for i in range(len(qb)):
    ndf = new_rg_df[new_rg_df['QB'] ==qb[i]]


    ttl_df = pd.pivot_table(ndf,index=['Region'], values=['COSTS'],aggfunc='sum').reset_index()
    ttl_df['Percent'] = ttl_df.iloc[:, 1:].apply(lambda x: x / x.sum())
    ttl_df = ttl_df.sort_values(by=['COSTS'], ascending=0)
    ttl_df.to_excel(writer, sheet_name='region',index=False, encoding='utf-8')
    ttl_df['Region'] = np.where(ttl_df['Percent']>0.00001, ttl_df['Region'], '')
    
    
    
    c_df = pd.pivot_table(ndf,index=['PART NUM BASE (CAUSL)'], values=['COSTS'],aggfunc='sum').reset_index()
    c_df['Percent'] = c_df.iloc[:, 1:].apply(lambda x: x / x.sum())
    # # c_df['Percent'] = c_df['Percent'].apply(lambda x: "{0:.2f}%".format(x*100))
    # # c_df['percentage'] = (c_df / c_df.groupby(['Country Repaired']).transform(sum))['COSTS']  # each group
    c_df = c_df.sort_values(by=['COSTS'], ascending=0)
    new_df = pd.merge(c_df, bpno_df ,how='left', on=['PART NUM BASE (CAUSL)'])
    new_df.to_excel(writer, sheet_name='part',index=False, encoding='utf-8')
    
    c_df['PART NUM BASE (CAUSL)'] = np.where(c_df['Percent']>0.02, c_df['PART NUM BASE (CAUSL)'], '')
    

    v_df = pd.pivot_table(ndf,index=['Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
    v_df['Percent'] = v_df.iloc[:, 1:].apply(lambda x: x / x.sum())
    v_df = v_df.sort_values(by=['COSTS'], ascending=0)
    v_df.to_excel(writer, sheet_name='vl',index=False, encoding='utf-8')
    v_df['vl'] = np.where(v_df['Percent']>0.02, v_df['Vehicle Line Global'].str.split(' - ').str[1], '')

    
    
    # my_xticks = ttl_df['Load Month']
    # y1 = ttl_df['COSTS']
    # y2 = ttl_df['CPR']
    # x = np.arange(len(my_xticks))



    fig = plt.figure(figsize=(12,8))
    ax1 = fig.add_subplot(232)
    # plt.suptitle('AP ' + qb[i] + ' CHART', fontsize=15,fontweight='bold')
    region= ttl_df['COSTS']
    c_labels = ttl_df['Region']
    ax1 = fig.add_subplot(232)
    ax1.pie(region, labels=c_labels, autopct=autopct_more_than_2)


    part= c_df['COSTS']
    c_labels = c_df['PART NUM BASE (CAUSL)']
    ax3 = fig.add_subplot(234)
    ax3.pie(part, labels=c_labels, autopct=autopct_more_than_2)


    vl = v_df['COSTS']
    v_labels = v_df['vl']
    ax4 = fig.add_subplot(236)
    ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_2)

    fig.tight_layout() 
    fig.savefig('C:/Users/jluo27/Desktop/AP_' + qb[i] + '.png')
writer.save()