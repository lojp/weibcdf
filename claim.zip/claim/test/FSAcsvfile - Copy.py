# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
from pandas import *
import re
import os
import warnings
import timeit
start = timeit.default_timer()
warnings.simplefilter("ignore")
# os.remove('C:/jluo/Export/Monthly/NEWCLAIMS.CSV')

cw = 'CLAIMLIS'
# cw = 'TISREP'

df = pd.read_csv('C:/jluo/Export/' + cw +'.CSV', warn_bad_lines=False, error_bad_lines=False, encoding='latin-1')
db = pd.read_csv('C:/jluo/Export/Monthly/Panda_BPNO.CSV', warn_bad_lines=False, error_bad_lines=False)

if cw == 'CLAIMLIS':
    ppno = df['Part Num Full OB (Causal)']
    lh = df['Labor Hours']
    ddf = pd.DataFrame()   
    ddf['PPF_PPNO'] = ppno.map(lambda x: re.sub(r'-', '', x).rstrip('*'))
    ddf['lhfloor'] = np.int_(np.floor(lh))
    ddf['lhceil'] = np.int_(np.ceil(lh))
    mdf = pd.merge(ddf, db[['PPF_PPNO', 'Panda_DESC']],how='left', on=['PPF_PPNO'])

    # print(mdf.head(15))

    # # df['Labor_Hours2'] = int(np.floor(lh)) 
    # # df['Labor_Hours2'] = np.int_(np.floor(lh)) + '~' + np.int_(np.ceil(lh))
    # # df['Labor_Hours2'] = np.int_((np.floor(lh))).astype(str) + '~' + np.int_((np.ceil(lh))).astype(str)
    df['Labor_Hours2'] = ddf[['lhfloor','lhceil']].apply(lambda x : '{}-{}'.format(x[0],x[1]), axis=1)
    df['Panda_DESC'] = mdf['Panda_DESC']
    # print(df.head(5))
    # print(df.columns.values)
    # colval = df.columns.values
    # for i in range(len(colval)):
	# print(i,colval[i])

    newcolumns = ['Model Year','VIN','Country Built','Country Sold','Country Repaired','Body/Cab Desc','Body/Cab Type [BS/CA]',
    'Condition Code','Condition Code Desc','Customer Concern Code','Customer Concern Code Desc','Document Number','Labor Hours','Labor_Hours2',
    'Labor Cost','Material Cost','Misc. Amt (total)','Total Cost Gross','Load Month','Production Month','Production Date','Repair Date','Warranty Start Date',
    'Tech Comments (English)','Customer Comments','Technician Comments','Repair Dealer Code','Repair Dealer Name',
    'Repair Dealer Phone Num','Sell Dealer Code','Mileage','TIS','Transmission [TR]','Transmission Desc','Claim Key','Vehicle Line Global',
    'Vehicle Line Global Desc','Engine [EN]','Engine Desc','WCC','WCC Desc','QB Global Sub Groups','Part Num Full OB (Causal)',
    'Part Num Prefix (Causal)','Part Num Base (Causal)','Part Num Suffix (Causal)','FCC Authorization','Panda_DESC']	
    df.to_csv('C:/jluo/Export/Monthly/FSA' + cw +'.CSV', encoding='utf-8',index=False,columns=newcolumns)	
elif cw == 'TISREP':
    df = df.drop(['MATRIX_NO','R1000','CPU','CPR','LOGIC'],axis=1)

    df['Vehicle Line Global'] = df['Vehicle Line Global'].str.split(' - ').str[0]
    df = df[(df['PART NUM BASE (CAUSL)'] != 'BLANK') & (df['PART NUM BASE (CAUSL)'] != 'TOTAL')]
    df = df.dropna(axis=0,how='any')
    df = df[df['MODEL YEAR'] >2010]
    df.to_csv('C:/jluo/Export/Monthly/FSA' + cw +'.CSV', encoding='utf-8',index=False)	

stop = timeit.default_timer()
print (round(stop - start,3),'s')