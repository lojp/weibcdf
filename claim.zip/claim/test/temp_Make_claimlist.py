# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import pyodbc
import csv
import numpy as np
import pandas as pd
import warnings
import timeit
import os
import sys
import shutil
start = timeit.default_timer()
warnings.simplefilter("ignore")


mydir = 'C:/jluo/data/New/'
ll = ['2015-01', '2015-02', '2015-03', '2015-04', '2015-05', '2015-06', '2015-07', '2015-08', 
    '2015-09', '2015-10', '2015-11', '2015-12','2016-01', '2016-02', '2016-03', '2016-04', 
    '2016-05', '2016-06', '2016-07', '2016-08', 
    '2016-09', '2016-10', '2016-11', '2016-12', '2017-01', '2017-02', '2017-03', '2017-04', 
    '2017-05', '2017-06', '2017-07', '2017-08', '2017-09', '2017-10', '2017-11']

dmt = pd.read_csv('C:/jluo/Export/Monthly/WCCCLAIMLIS.CSV', encoding='utf-8')
dff = dmt[dmt['Load Month'].isin(ll)]
# clmlist = dff[dff['WCC']=='7A01']
writer = pd.ExcelWriter(mydir + 'battery.xls', engine='xlsxwriter')
dt1 = pd.DataFrame(clmlist)	
dt1.to_excel(writer, sheet_name='claimlist1',index=False, encoding='utf-8')
writer.save()