# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""

from shareplum import Site
from requests_ntlm import HttpNtlmAuth
import pandas as pd
import numpy as np
import re
import warnings
import timeit
from datetime import date, timedelta, datetime
from dduplicate import *
import os
import subprocess
import glob
warnings.simplefilter("ignore")
start = timeit.default_timer()

field_list =['SpikeNum','SpikeTitle','SpikeStage','Supplier','GQBCode','LastStatus','ActionOwner','ExpectedDate','VehLine','PartNum','PDEngineer','PDLead','Buyer','PurchLead','DetailedNotes','DateOpened','STG2Start','STG3Start','STG4Start','STG5Start','STG6Start','DateClosed','STATUS']

site_url = "https://qua.spt.ford.com/sites/CoverageSpikeRecovery/"   #remove the suffix of link, just keep 'site + type'
site_listID ='{3442125e-3aca-4b57-9654-0b0cca866eef}'  #Use google chrome to check 'toolbarData['ListId']=
cred = HttpNtlmAuth('fordap1\\jluo27','panda000')
df = pd.DataFrame([])

site = Site(site_url, auth=cred)
sp_site_list = site.List(site_listID)
list_data = sp_site_list.GetListItems(fields=field_list)
df_data = pd.DataFrame(list_data)
df = df.append(df_data)
df.to_csv('C:/jluo/SpikeRecovery/sharepointCSV/spike' + str(date.today()) + '.CSV', encoding='utf-8',index=False)

list_of_files = glob.glob('C:/jluo/SpikeRecovery/sharepointCSV/*') # * means all if need specific format then *.csv
latest_file = max(list_of_files, key=os.path.getctime)

df1 = pd.read_csv('C:/jluo/SpikeRecovery/sharepointCSV/spike' + str(date.today()) + '.CSV', encoding='utf-8')
df2 = pd.read_csv(latest_file, encoding='utf-8')

df_diff = df1[['SpikeNum','LastStatus']].merge(df2[['SpikeNum','LastStatus']], how = 'outer' ,indicator=True).loc[lambda x : x['_merge']=='left_only']
print(df_diff)
