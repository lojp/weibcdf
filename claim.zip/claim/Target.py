# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
from matplotlib.gridspec import GridSpec

df = pd.read_csv('C:/jluo/Export/DATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')   #skiprows=3
# df['CTY'] = df['Country Sold'].str.split(' - ').str[0]
# df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
# df['VL_DESC'] = df['Vehicle Line Global'].str.split(' - ').str[1]
df['QB'] = df['QB Global Sub Group'].str[:4]
df['SubQB'] = df['QB Global Sub Group'].str[:5]
df['Year'] = df['Load Month'].str.split('-').str[0].astype(np.int64)
df['Month'] = df['Load Month'].str.split('-').str[1].astype(np.int64)
# print(df.head(5))


# df = df[(df['PART NUM BASE (CAUSL)']=='P600D00')]
# df = df[df['PART NUM BASE (CAUSL)'].str.contains('782')]
# df = df[(df['PART NUM BASE (CAUSL)']=='2141022') | (df['PART NUM BASE (CAUSL)']=='2141023') ]
# df = df[df['QB'].str.contains('GQB5')]
df = df[df['SubQB'].str.contains('GQB5')]
# df = df[df['Load Month'].str.contains('2015')]
# df = df[df['VFG'].str.contains('V31')]
# df = df[df['Vehicle Line Global'].str.contains('RANGER')]
# df = df[df['VL']=='ZB']
# df = df[df['WCC_Code']=='7A01']
# df = df[df['Country Repaired'].str.contains('AUS')]
# df = df[(df['PART NUM BASE (CAUSL)']=='3F830') & (df['VL']=='K3')]
# df = df[df['Load Month'].str.contains('2017')]

# # # # 输出数据到excel
# vl_df = pd.pivot_table(df,index=['Load Month','Vehicle Line Global'], values=['COSTS','REPAIRS'],aggfunc='sum').reset_index()
# writer = pd.ExcelWriter('C:/Users/jluo27/Desktop/GQB5.xlsx', engine='xlsxwriter')
# vl_df.to_excel(writer, sheet_name='rawdata',index=False, encoding='utf-8')
# writer.save()

# ttl_df = pd.pivot_table(df,index=['QB','Year','TIS'],values=['COSTS'],aggfunc='sum').reset_index()
# writer = pd.ExcelWriter('C:/Users/jluo27/Desktop/GQB.xlsx', engine='xlsxwriter')
# ttl_df.to_excel(writer, sheet_name='rawdata',index=False, encoding='utf-8')
# writer.save()

# ——————————————————————————————————————————————————————————————————————————————————————————————————
# ttl_df = pd.pivot_table(df,index=['Load Month'], values=['COSTS'],aggfunc='sum').reset_index()
# my_xticks = ttl_df['Load Month']
# y = ttl_df['COSTS']
# # y1 = ttl_df['COSTS'].rolling(window=3, center=False).mean()
# x = np.arange(len(my_xticks))
# # plt.style.use('ggplot')
# fig = plt.figure(figsize=(10,6))
# plt.xticks(x, my_xticks,rotation=90, fontsize=7)   #plt.xticks(x, my_xticks,rotation=90, fontsize=7)
# plt.plot(x,y,'r-',linewidth=1.5, alpha=0.9, label='Actual')
# # plt.plot(x,y1,'y-',label='MA3')

# palette = plt.get_cmap('Set1')
# ma_list = [3, 6, 9]
# for ma in ma_list:
    # plt.plot(x, ttl_df['COSTS'].rolling(window=ma, center=False).mean(), '--', color=palette(ma), linewidth=1.5, alpha=0.9, label='MA' + str(ma))

# # plt.ylim(ymin=0)
# # plt.ylabel("Cumulative density")
# # plt.xlabel("TIS")
# # plt.title('lod', fontsize=16)		 
# plt.legend()
# plt.subplots_adjust(left=0.08, right=0.97, top=0.98, bottom=0.1)
# plt.show()
# plt.savefig('C:/Users/jluo27/Desktop/GQ1.png')
# ——————————————————————————————————————————————————————————————————————————————————————————————————

# print(df.describe())
# ——————————————————————————————————————————————————————————————————————————————————————————————————
# ttl_df = pd.pivot_table(df,index=['Month'],columns =['Year'],values=['COSTS'],aggfunc='sum').reset_index()
# # ttl_df.columns = p_column
# palette = plt.get_cmap('Set1')
 
# # multiple line plot
# num=0
# for column in ttl_df.drop('Month', axis=1):
    # num+=1
    # plt.plot(ttl_df['Month'], ttl_df[column]/1000000, marker='', color=palette(num), linewidth=1.5, alpha=0.9, label=column)
# # Add legend
# plt.legend(loc='center left', bbox_to_anchor=(1.04,0.5), borderaxespad=0)
# # plt.ylim(ymin=0)
# plt.title("Warranty spends trend", loc='center', fontsize=12, fontweight=0, color='b')
# plt.xlabel("Month")
# plt.ylabel("Costs($Million)")
# plt.show()
# # ——————————————————————————————————————————————————————————————————————————————————————————————————

# ——————————————————————————————————————————————————————————————————————————————————————————————————
ttl_df = pd.pivot_table(df,index=['Year'],values=['COSTS'],aggfunc='sum').reset_index()
ttl_df['inc'] = ttl_df['COSTS'].pct_change()*100

ytd_df = pd.pivot_table(df[df['Month']<12],index=['Year'],values=['COSTS'],aggfunc='sum').reset_index()
ytd_df['inc'] = ytd_df['COSTS'].pct_change()*100

r = ytd_df.loc[ytd_df['Year']==2018, ['inc']].values
a = ttl_df.loc[ttl_df['Year']==2017, ['COSTS']].values
b = ttl_df.loc[ttl_df['Year']==2018, ['COSTS']].values

ttl_df.loc[ttl_df['Year']==2018, ['inc']] =ytd_df.loc[ytd_df['Year']==2018, ['inc']]
new = pd.DataFrame([0,0,0,0,0,(r/100+1)*a-b], index=[0,1,2,3,4,5], columns=['NEWCOSTS'])
ttl_df = ttl_df.add(new, fill_value=0)

fig = plt.figure(figsize=(6,4))
plt.suptitle('YOY PERFORMANCE FOR GQB5 BODY INTERIOR')
ax1 = fig.add_subplot(111)
b1 = ax1.bar(ttl_df['Year'], ttl_df['COSTS'], align='center', alpha=0.5)  
b2 = ax1.bar(ttl_df['Year'], ttl_df['NEWCOSTS'], align='center', alpha=0.5, bottom=ttl_df['COSTS'])

for a,b,c in zip(ttl_df['Year'],ttl_df['COSTS'],ttl_df['inc']):
    ax1.text(a, b+0.005, '%.0f%%' % c, ha='center', va= 'bottom',fontsize=10)

ax1.set_ylabel('Warranty Spends')
plt.show()
# # ——————————————————————————————————————————————————————————————————————————————————————————————————


# ——————————————————————————————————————————————————————————————————————————————————————————————————
# ttl_df = pd.pivot_table(df,index=['TIS'],values=['COSTS'],aggfunc='sum').reset_index()
# ttl_df['Percent'] = ttl_df.iloc[:, 1:].apply(lambda x: x / x.sum())
# ttl_df['Cum_Percent'] = ttl_df['Percent'].cumsum()
# x = ttl_df['TIS'] 
# y2 = ttl_df['Cum_Percent'] 
# my_xticks = ttl_df['TIS']

# fig = plt.figure()
# ax1 = fig.add_subplot(111)
# plt.suptitle('MY2018 Costs Pareto Chart by TIS', fontsize=15,fontweight='bold')
# ax1.plot(x, y2, 'b*--',label = 'Cum Percent')
# ax1.set_xlim(-1, 36)
# ax1.set_xlabel('TIS')
# ax1.set_ylabel('cum')
# ax1.set_xticks(x)
# ax1.set_xticklabels(my_xticks)

# for a,b in zip(x,y2):
    # if a % 3 == 0:
        # ax1.text(a, b, '{:.0f}%'.format(b*100), ha='center', va= 'bottom',fontsize=7)

# plt.show()
# # ——————————————————————————————————————————————————————————————————————————————————————————————————


# fig = plt.figure(figsize=(11,7))

# # ax1 = plt.subplot2grid((2, 3), (0, 0))
# ax1 = plt.subplot2grid((2, 3), (0, 0), colspan=2)
# ax3 = plt.subplot2grid((2, 3), (1, 0), colspan=1, rowspan=1)
# ax4 = plt.subplot2grid((2, 3), (1, 2), rowspan=1)


# # ax1 = fig.add_subplot(211)
# ax1.set_xlabel('Load Month')
# ax1.set_ylabel('warranty spends($K)')
# lns1 = ax1.plot(x, y1, 'ko-',label = 'Warranty spends')
# ax1.set_ylim(0,1.2*ttl_df.COSTS.max()/1000)
# ax1.set_xticks(x)
# ax1.set_xticklabels(my_xticks, rotation=90, fontsize=7)

# ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
# ax2.set_ylabel('CPR')  # we already handled the x-label with ax1
# lns2 =ax2.plot(x, y2, 'b*--',label = 'CPR')
# ax2.set_ylim(0,1.1*ttl_df.CPR.max())

# lns = lns1+lns2
# labs = [l.get_label() for l in lns]
# ax1.legend(lns, labs, loc=0)


# def autopct_more_than_1(pct):
    # return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data

# cty = c_df['COSTS']
# c_labels = c_df['cty']
# # ax3 = fig.add_subplot(234)
# ax3.pie(cty, labels=c_labels, autopct=autopct_more_than_1)
# # # # ax3.pie(cty, labels=c_labels, autopct='%.0f%%')
# # patches, texts, autotexts = ax3.pie(cty, labels=c_labels, autopct=autopct_more_than_1)
# # for t in texts:
    # # t.set_size('smaller')
# # for t in autotexts:
    # # t.set_size('x-small')

# vl = v_df['COSTS']
# v_labels = v_df['vl']
# # ax4 = fig.add_subplot(236)
# ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_1)


# fig.set_tight_layout(True)
# fig.savefig('C:/Users/jluo27/Desktop/foo.png')
# plt.show()

