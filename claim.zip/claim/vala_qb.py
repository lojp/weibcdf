# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import csv
import numpy as np
import pandas as pd
import timeit
import os
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
from datetime import date, timedelta, datetime
from collections import OrderedDict

dates = ["2017-03-01", str(date.today().replace(day=1) - timedelta(days=1))]
start, end = [datetime.strptime(_, "%Y-%m-%d") for _ in dates]
list_month = list(OrderedDict(((start + timedelta(_)).strftime(r"%Y-%m"), None) for _ in range((end - start).days)).keys())

# print(list_month)
# qb = ['GQB1', 'GQB2', 'GQB3', 'GQB4', 'GQB5', 'GQB6', 'GQB7']
qb = ['GQB5']
	 
df = pd.read_csv('C:/jluo/Export/Monthly/PYDATA.CSV', encoding='cp65001', warn_bad_lines=False, error_bad_lines=False,engine='python')
df['VL'] = df['Vehicle Line Global'].str.split(' - ').str[0]
df['WCC_Code'] = df['WCC'].str.split(' - ').str[0]
df['QB'] = df['QB Global Sub Group'].str[:4]
df = df[df['Load Month'].isin(list_month)]



def autopct_more_than_2(pct):
    return ('%.0f%%' % pct) if pct > 2 else ''  ###remove little data
    
def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 1 else ''  ###remove little data

    
    
bpno_df = pd.read_csv('C:/jluo/Export/Monthly/BPNO.csv', encoding='utf-8')
bpno_df.columns = ['PART NUM BASE (CAUSL)', 'Description']

writer = pd.ExcelWriter('C:/Users/jluo27/Desktop/all_QB.xls', engine='xlsxwriter')   
for i in range(len(qb)):
    ndf = df[df['QB'] ==qb[i]]

    ttl_df = pd.pivot_table(ndf,index=['Load Month'], values=['COSTS','REPAIRS'],aggfunc='sum').reset_index()
    ttl_df['CPR'] =ttl_df.COSTS/ttl_df.REPAIRS

    c_df = pd.pivot_table(ndf,index=['PART NUM BASE (CAUSL)'], values=['COSTS'],aggfunc='sum').reset_index()
    c_df['Percent'] = c_df.iloc[:, 1:].apply(lambda x: x / x.sum())
    # # c_df['Percent'] = c_df['Percent'].apply(lambda x: "{0:.2f}%".format(x*100))
    # # c_df['percentage'] = (c_df / c_df.groupby(['Country Repaired']).transform(sum))['COSTS']  # each group
    c_df = c_df.sort_values(by=['COSTS'], ascending=0)
    new_df = pd.merge(c_df, bpno_df ,how='left', on=['PART NUM BASE (CAUSL)'])
    new_df.head(20).to_excel(writer, sheet_name=qb[i],index=False, encoding='utf-8')
    
    c_df['PART NUM BASE (CAUSL)'] = np.where(c_df['Percent']>0.02, c_df['PART NUM BASE (CAUSL)'], '')
    

    v_df = pd.pivot_table(ndf,index=['Vehicle Line Global'], values=['COSTS'],aggfunc='sum').reset_index()
    v_df['Percent'] = v_df.iloc[:, 1:].apply(lambda x: x / x.sum())
    v_df = v_df.sort_values(by=['COSTS'], ascending=0)
    v_df['vl'] = np.where(v_df['Percent']>0.02, v_df['Vehicle Line Global'].str.split(' - ').str[1], '')

    my_xticks = ttl_df['Load Month']
    y1 = ttl_df['COSTS']
    y2 = ttl_df['CPR']
    x = np.arange(len(my_xticks))



    fig = plt.figure(figsize=(12,8))
    ax1 = fig.add_subplot(211)
    plt.suptitle('AP ' + qb[i] + ' CHART', fontsize=15,fontweight='bold')
    ax1.set_xlabel('Load Month')
    ax1.set_ylabel('warranty spends')
    lns1 = ax1.plot(x, y1, 'C1o-',label = 'Warranty spends')
    ax1.set_ylim(ymin=0)
    ax1.set_xticks(x)
    ax1.set_xticklabels(my_xticks, rotation=90, fontsize=7)

    ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
    ax2.set_ylabel('CPR')  # we already handled the x-label with ax1
    lns2 =ax2.plot(x, y2, '*--',label = 'CPR')
    ax2.set_ylim(ymin=0)

    lns = lns1+lns2
    labs = [l.get_label() for l in lns]
    ax1.legend(lns, labs, loc=0)


    part= c_df['COSTS']
    c_labels = c_df['PART NUM BASE (CAUSL)']
    ax3 = fig.add_subplot(234)
    ax3.pie(part, labels=c_labels, autopct=autopct_more_than_2)


    vl = v_df['COSTS']
    v_labels = v_df['vl']
    ax4 = fig.add_subplot(236)
    ax4.pie(vl, labels=v_labels, autopct=autopct_more_than_2)

    fig.tight_layout() 
    fig.savefig('C:/Users/jluo27/Desktop/AP_' + qb[i] + '.png')
writer.save()