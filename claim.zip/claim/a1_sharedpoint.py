# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""

from shareplum import Site
from requests_ntlm import HttpNtlmAuth
import pandas as pd
import numpy as np
import re
import warnings
import timeit
from dduplicate import *
import os
import subprocess
warnings.simplefilter("ignore")
start = timeit.default_timer()
# import requests
# from requests_ntlm import HttpNtlmAuth
# r = requests.get(site_url, auth=HttpNtlmAuth('fordap1\\jluo27','panda110'))

# def f5(seq, idfun=None):  
    # # order preserving 
    # if idfun is None: 
        # def idfun(x): return x 
    # seen = {} 
    # result = [] 
    # for item in seq: 
        # marker = idfun(item) 
        # # in old Python versions: 
        # # if seen.has_key(marker) 
        # # but in new ones: 
        # if marker in seen: continue 
        # seen[marker] = 1 
        # result.append(item) 
    # return result



mypath = 'C:/jluo/Export/Monthly/'
server_url = "https://www.wspend.ford.com/sites/"
# site_url = server_url + "sites/APElectrical/Lists/Workstreams/AllItems.aspx"
server_suf_list = ['APElectrical','APBE','APBI']
site_listID =['{2EB14949-2E87-464D-915B-49EED04C0034}','{D4589B6F-C2FF-4DFD-91E5-304EF0A36EE0}','{56EC00A2-BC65-49BD-8703-CBE9856CF2CD}']  #Use google chrome to check 'toolbarData['ListId']='
action_listID = ['{9e34ca1d-bedb-4b48-ba5c-3b6e4bc9e07e}','{099c4b16-d7c0-4d83-9d1d-d3abea5c3fe6}','{badef527-4416-4759-8684-f54633d27bb3}']
cred = HttpNtlmAuth('fordap1\\jluo27','panda2019')
pd_list = pd.DataFrame([])
act_list = pd.DataFrame([])

for i in range(len(server_suf_list)):
    site = Site(server_url + server_suf_list[i], auth=cred)
    sp_site_list = site.List(site_listID[i])
    sp_act_list = site.List(action_listID[i])
    # list_data = sp_site_list.GetListItems('All Items')
    list_data = sp_site_list.GetListItems(fields=['Description','Workstream','Part #1','Part #2','Part #3','Part #4','Part #5','Part #6','Part #7','Part #8'])
    act_data = sp_act_list.GetListItems(fields=['Action','WS Reduction Tool Category','Description','Impl. Date','Implementation Status'])
    pd_list_data = pd.DataFrame(list_data)
    pd_list = pd_list.append(pd_list_data)
    act_list_data = pd.DataFrame(act_data)
    act_list = act_list.append(act_list_data)

act_list['Workstream'] = act_list['Action'].str[0:11]
act_df = pd.merge(act_list, pd_list[['Workstream', 'Description']],how='left', on=['Workstream'])
act_df.to_csv('C:/jluo/Export/Monthly/Actionlist.CSV', encoding='utf-8',index=False)

pd_list['PartSum'] = pd_list[['Part #1','Part #2','Part #3','Part #4','Part #5','Part #6','Part #7','Part #8']].apply(lambda x: ','.join(x.dropna()), axis=1)
pd_list['PartSum'] = [x.upper().strip().replace(' ', '') for x in pd_list['PartSum']]
pd_list['PartSum'] = [x.upper().strip().replace(';', ',') for x in pd_list['PartSum']]
pd_list['PartSum'] = pd_list['PartSum'].astype('str')
# # # pd_list['PartSum'] = [x.strip().replace(' ', '') for x in pd_list['PartSum']] #set.add(x) or x for x in seq if x not in seen
pd_list['Item_Desc'] = pd_list['Description'].str.split(' - |--').str[0]
pd_list['Item_Desc'][pd_list['Item_Desc'].str.contains('Hood')] = 'Hood'
pd_list['vd'] = pd_list['Description'].str.split(' - |--').str[1]
df = pd.pivot_table(pd_list,index=['vd'], values=['Workstream'],aggfunc='count').reset_index()
vdroadmap = f5(pd_list['vd'])
# df.to_csv('C:/jluo/Export/vl_sharepoint.CSV', encoding='utf-8',index=False)
# pd_list.to_csv('C:/jluo/Export/Monthly/share.CSV', encoding='utf-8',index=False,columns=['Workstream','Description','vd','PartSum'])
# print(pd_list)
# print(pd_list_data.head(5))


vl_info = pd.read_excel('C:/jluo/Export/vl.xlsx', sheet_name='Sheet2')
vdlist = f5(vl_info['vd'])
count=0
for k in range(len(vdroadmap)):
    if vdroadmap[k] not in vdlist:
        print(vdroadmap[k])
        count +=1
        if count >2:
            os.startfile('C:/jluo/Export/vl.xlsx')

vl_info_df = vl_info.groupby('vd')['vl'].apply(lambda x: ','.join(x)).reset_index()
# print(vl_info_df)
pd_list = pd.merge(pd_list, vl_info_df,how='left', on='vd')
all_list_df = vl_info_df[vl_info_df['vd']=='AP Repaired']['vl'].tolist()
all_list = [c.split(',') for c in all_list_df]

oth_df = pd_list[pd_list['vd'] == 'Other VLs']
ext_df = pd_list[pd_list['vd'] != 'Other VLs']
o_list = oth_df['Item_Desc'].tolist()


oth = []
for i in range(len(o_list)):
    try:
        d = pd_list[(pd_list['Item_Desc'] == o_list[i]) & (pd_list['vd'] != 'Other VLs')]
        othdata = d.groupby('Item_Desc')['vl'].apply(lambda x: ','.join(x)).reset_index()
        ext_list_df = othdata['vl'].tolist()
        ext_list = [c.split(',') for c in ext_list_df]
        rest_list = [c for c in all_list[0] if not c in ext_list[0]]
        oth_data = ','.join(rest_list)
        oth.append(oth_data)
    except:
        # print('4')
        continue

	
t = pd.DataFrame(list(zip(o_list, oth)),columns=['Item_Desc','vl'])
tt = pd.merge(oth_df.drop(['vl'],axis=1), t,how='left', on='Item_Desc')
pd_list = pd.concat([ext_df,tt],ignore_index=True)

pd_list['Type']=0
for j in range(len(pd_list)):
    if pd_list['vl'][[j]].isnull().values.any() == True:
        pd_list['Type'][[j]] = 0
    elif pd_list['PartSum'][[j]].str.contains('WCC|wcc', na=False).values.any() == True:
        pd_list['Type'][[j]] = 1
    else:
        pd_list['Type'][[j]] = 2


pd_list['item'] = 'GQB' + pd_list['Workstream'].str[4:5] + '_' + pd_list['Description']
pd_list.sort_values(by=['Type','item'], ascending=[True,True]).to_csv(mypath +'Partlist.CSV', encoding='utf-8',index=False,columns=['Type','item','PartSum','vl'])


subprocess.check_call(["python", "C:\Private\Analysis\python\mine\claim\First_splittool.py"])
print ('-----------------------------------' +  '\n' + '***Have Split the Part&Vehicles, and Saved***' +  '\n' + '-----------------------------------')

stop = timeit.default_timer()
print (round(stop - start,3),'s')
os.startfile('C:/jluo/tool/AP_Update criteria Tool_V2.xls')